# generated from rosidl_generator_py/resource/_idl.py.em
# with input from autonomy_msgs:msg/Path.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Path(type):
    """Metaclass of message 'Path'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autonomy_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autonomy_msgs.msg.Path')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__path
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__path
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__path
            cls._TYPE_SUPPORT = module.type_support_msg__msg__path
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__path

            from autonomy_msgs.msg import CoordinateSystemInfo
            if CoordinateSystemInfo.__class__._TYPE_SUPPORT is None:
                CoordinateSystemInfo.__class__.__import_type_support__()

            from autonomy_msgs.msg import PoseWithTwist
            if PoseWithTwist.__class__._TYPE_SUPPORT is None:
                PoseWithTwist.__class__.__import_type_support__()

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class Path(metaclass=Metaclass_Path):
    """Message class 'Path'."""

    __slots__ = [
        '_uuid',
        '_name',
        '_header',
        '_info',
        '_poses',
    ]

    _fields_and_field_types = {
        'uuid': 'string',
        'name': 'string',
        'header': 'std_msgs/Header',
        'info': 'autonomy_msgs/CoordinateSystemInfo',
        'poses': 'sequence<autonomy_msgs/PoseWithTwist>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['autonomy_msgs', 'msg'], 'CoordinateSystemInfo'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['autonomy_msgs', 'msg'], 'PoseWithTwist')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.uuid = kwargs.get('uuid', str())
        self.name = kwargs.get('name', str())
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        from autonomy_msgs.msg import CoordinateSystemInfo
        self.info = kwargs.get('info', CoordinateSystemInfo())
        self.poses = kwargs.get('poses', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.uuid != other.uuid:
            return False
        if self.name != other.name:
            return False
        if self.header != other.header:
            return False
        if self.info != other.info:
            return False
        if self.poses != other.poses:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def uuid(self):
        """Message field 'uuid'."""
        return self._uuid

    @uuid.setter
    def uuid(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'uuid' field must be of type 'str'"
        self._uuid = value

    @builtins.property
    def name(self):
        """Message field 'name'."""
        return self._name

    @name.setter
    def name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'name' field must be of type 'str'"
        self._name = value

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def info(self):
        """Message field 'info'."""
        return self._info

    @info.setter
    def info(self, value):
        if __debug__:
            from autonomy_msgs.msg import CoordinateSystemInfo
            assert \
                isinstance(value, CoordinateSystemInfo), \
                "The 'info' field must be a sub message of type 'CoordinateSystemInfo'"
        self._info = value

    @builtins.property
    def poses(self):
        """Message field 'poses'."""
        return self._poses

    @poses.setter
    def poses(self, value):
        if __debug__:
            from autonomy_msgs.msg import PoseWithTwist
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, PoseWithTwist) for v in value) and
                 True), \
                "The 'poses' field must be a set or sequence and each value of type 'PoseWithTwist'"
        self._poses = value
