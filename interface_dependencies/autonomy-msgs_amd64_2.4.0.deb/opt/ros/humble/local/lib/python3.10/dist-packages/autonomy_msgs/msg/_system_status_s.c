// generated from rosidl_generator_py/resource/_idl_support.c.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <Python.h>
#include <stdbool.h>
#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-function"
#endif
#include "numpy/ndarrayobject.h"
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif
#include "rosidl_runtime_c/visibility_control.h"
#include "autonomy_msgs/msg/detail/system_status__struct.h"
#include "autonomy_msgs/msg/detail/system_status__functions.h"

#include "rosidl_runtime_c/string.h"
#include "rosidl_runtime_c/string_functions.h"


ROSIDL_GENERATOR_C_EXPORT
bool autonomy_msgs__msg__system_status__convert_from_py(PyObject * _pymsg, void * _ros_message)
{
  // check that the passed message is of the expected Python class
  {
    char full_classname_dest[46];
    {
      char * class_name = NULL;
      char * module_name = NULL;
      {
        PyObject * class_attr = PyObject_GetAttrString(_pymsg, "__class__");
        if (class_attr) {
          PyObject * name_attr = PyObject_GetAttrString(class_attr, "__name__");
          if (name_attr) {
            class_name = (char *)PyUnicode_1BYTE_DATA(name_attr);
            Py_DECREF(name_attr);
          }
          PyObject * module_attr = PyObject_GetAttrString(class_attr, "__module__");
          if (module_attr) {
            module_name = (char *)PyUnicode_1BYTE_DATA(module_attr);
            Py_DECREF(module_attr);
          }
          Py_DECREF(class_attr);
        }
      }
      if (!class_name || !module_name) {
        return false;
      }
      snprintf(full_classname_dest, sizeof(full_classname_dest), "%s.%s", module_name, class_name);
    }
    assert(strncmp("autonomy_msgs.msg._system_status.SystemStatus", full_classname_dest, 45) == 0);
  }
  autonomy_msgs__msg__SystemStatus * ros_message = _ros_message;
  {  // is_operational
    PyObject * field = PyObject_GetAttrString(_pymsg, "is_operational");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->is_operational = (Py_True == field);
    Py_DECREF(field);
  }
  {  // behavior_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "behavior_status");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->behavior_status, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // position_accuracy_status
    PyObject * field = PyObject_GetAttrString(_pymsg, "position_accuracy_status");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->position_accuracy_status, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }
  {  // scheduling_enabled
    PyObject * field = PyObject_GetAttrString(_pymsg, "scheduling_enabled");
    if (!field) {
      return false;
    }
    assert(PyBool_Check(field));
    ros_message->scheduling_enabled = (Py_True == field);
    Py_DECREF(field);
  }
  {  // mode_of_operation
    PyObject * field = PyObject_GetAttrString(_pymsg, "mode_of_operation");
    if (!field) {
      return false;
    }
    assert(PyUnicode_Check(field));
    PyObject * encoded_field = PyUnicode_AsUTF8String(field);
    if (!encoded_field) {
      Py_DECREF(field);
      return false;
    }
    rosidl_runtime_c__String__assign(&ros_message->mode_of_operation, PyBytes_AS_STRING(encoded_field));
    Py_DECREF(encoded_field);
    Py_DECREF(field);
  }

  return true;
}

ROSIDL_GENERATOR_C_EXPORT
PyObject * autonomy_msgs__msg__system_status__convert_to_py(void * raw_ros_message)
{
  /* NOTE(esteve): Call constructor of SystemStatus */
  PyObject * _pymessage = NULL;
  {
    PyObject * pymessage_module = PyImport_ImportModule("autonomy_msgs.msg._system_status");
    assert(pymessage_module);
    PyObject * pymessage_class = PyObject_GetAttrString(pymessage_module, "SystemStatus");
    assert(pymessage_class);
    Py_DECREF(pymessage_module);
    _pymessage = PyObject_CallObject(pymessage_class, NULL);
    Py_DECREF(pymessage_class);
    if (!_pymessage) {
      return NULL;
    }
  }
  autonomy_msgs__msg__SystemStatus * ros_message = (autonomy_msgs__msg__SystemStatus *)raw_ros_message;
  {  // is_operational
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->is_operational ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "is_operational", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // behavior_status
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->behavior_status.data,
      strlen(ros_message->behavior_status.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "behavior_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // position_accuracy_status
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->position_accuracy_status.data,
      strlen(ros_message->position_accuracy_status.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "position_accuracy_status", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // scheduling_enabled
    PyObject * field = NULL;
    field = PyBool_FromLong(ros_message->scheduling_enabled ? 1 : 0);
    {
      int rc = PyObject_SetAttrString(_pymessage, "scheduling_enabled", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }
  {  // mode_of_operation
    PyObject * field = NULL;
    field = PyUnicode_DecodeUTF8(
      ros_message->mode_of_operation.data,
      strlen(ros_message->mode_of_operation.data),
      "replace");
    if (!field) {
      return NULL;
    }
    {
      int rc = PyObject_SetAttrString(_pymessage, "mode_of_operation", field);
      Py_DECREF(field);
      if (rc) {
        return NULL;
      }
    }
  }

  // ownership of _pymessage is transferred to the caller
  return _pymessage;
}
