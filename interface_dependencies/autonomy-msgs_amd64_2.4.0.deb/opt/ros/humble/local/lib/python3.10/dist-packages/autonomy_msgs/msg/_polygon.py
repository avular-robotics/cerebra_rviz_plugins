# generated from rosidl_generator_py/resource/_idl.py.em
# with input from autonomy_msgs:msg/Polygon.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Polygon(type):
    """Metaclass of message 'Polygon'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autonomy_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autonomy_msgs.msg.Polygon')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__polygon
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__polygon
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__polygon
            cls._TYPE_SUPPORT = module.type_support_msg__msg__polygon
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__polygon

            from autonomy_msgs.msg import CoordinateSystemInfo
            if CoordinateSystemInfo.__class__._TYPE_SUPPORT is None:
                CoordinateSystemInfo.__class__.__import_type_support__()

            from geometry_msgs.msg import Point
            if Point.__class__._TYPE_SUPPORT is None:
                Point.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'RIGHT_SIDED__DEFAULT': True,
        }

    @property
    def RIGHT_SIDED__DEFAULT(cls):
        """Return default value for message field 'right_sided'."""
        return True


class Polygon(metaclass=Metaclass_Polygon):
    """Message class 'Polygon'."""

    __slots__ = [
        '_uuid',
        '_name',
        '_info',
        '_points',
        '_right_sided',
    ]

    _fields_and_field_types = {
        'uuid': 'string',
        'name': 'string',
        'info': 'autonomy_msgs/CoordinateSystemInfo',
        'points': 'sequence<geometry_msgs/Point>',
        'right_sided': 'boolean',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['autonomy_msgs', 'msg'], 'CoordinateSystemInfo'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.uuid = kwargs.get('uuid', str())
        self.name = kwargs.get('name', str())
        from autonomy_msgs.msg import CoordinateSystemInfo
        self.info = kwargs.get('info', CoordinateSystemInfo())
        self.points = kwargs.get('points', [])
        self.right_sided = kwargs.get(
            'right_sided', Polygon.RIGHT_SIDED__DEFAULT)

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.uuid != other.uuid:
            return False
        if self.name != other.name:
            return False
        if self.info != other.info:
            return False
        if self.points != other.points:
            return False
        if self.right_sided != other.right_sided:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def uuid(self):
        """Message field 'uuid'."""
        return self._uuid

    @uuid.setter
    def uuid(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'uuid' field must be of type 'str'"
        self._uuid = value

    @builtins.property
    def name(self):
        """Message field 'name'."""
        return self._name

    @name.setter
    def name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'name' field must be of type 'str'"
        self._name = value

    @builtins.property
    def info(self):
        """Message field 'info'."""
        return self._info

    @info.setter
    def info(self, value):
        if __debug__:
            from autonomy_msgs.msg import CoordinateSystemInfo
            assert \
                isinstance(value, CoordinateSystemInfo), \
                "The 'info' field must be a sub message of type 'CoordinateSystemInfo'"
        self._info = value

    @builtins.property
    def points(self):
        """Message field 'points'."""
        return self._points

    @points.setter
    def points(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'points' field must be a set or sequence and each value of type 'Point'"
        self._points = value

    @builtins.property
    def right_sided(self):
        """Message field 'right_sided'."""
        return self._right_sided

    @right_sided.setter
    def right_sided(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'right_sided' field must be of type 'bool'"
        self._right_sided = value
