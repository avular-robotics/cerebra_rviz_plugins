# generated from rosidl_generator_py/resource/_idl.py.em
# with input from autonomy_msgs:msg/SystemStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SystemStatus(type):
    """Metaclass of message 'SystemStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'UNKNOWN': 'unknown',
        'INACCURATE_POSITION': 'inaccurate_position',
        'INACCURATE_HEADING': 'inaccurate_heading',
        'ACCURATE': 'accurate',
        'DEFAULT': 'default',
        'MAPPING': 'mapping',
        'MULTIMAP': 'multimap',
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autonomy_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autonomy_msgs.msg.SystemStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__system_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__system_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__system_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__system_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__system_status

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'UNKNOWN': cls.__constants['UNKNOWN'],
            'INACCURATE_POSITION': cls.__constants['INACCURATE_POSITION'],
            'INACCURATE_HEADING': cls.__constants['INACCURATE_HEADING'],
            'ACCURATE': cls.__constants['ACCURATE'],
            'DEFAULT': cls.__constants['DEFAULT'],
            'MAPPING': cls.__constants['MAPPING'],
            'MULTIMAP': cls.__constants['MULTIMAP'],
            'IS_OPERATIONAL__DEFAULT': False,
            'BEHAVIOR_STATUS__DEFAULT': 'No information yet.',
            'POSITION_ACCURACY_STATUS__DEFAULT': 'unknown',
            'SCHEDULING_ENABLED__DEFAULT': False,
            'MODE_OF_OPERATION__DEFAULT': 'default',
        }

    @property
    def UNKNOWN(self):
        """Message constant 'UNKNOWN'."""
        return Metaclass_SystemStatus.__constants['UNKNOWN']

    @property
    def INACCURATE_POSITION(self):
        """Message constant 'INACCURATE_POSITION'."""
        return Metaclass_SystemStatus.__constants['INACCURATE_POSITION']

    @property
    def INACCURATE_HEADING(self):
        """Message constant 'INACCURATE_HEADING'."""
        return Metaclass_SystemStatus.__constants['INACCURATE_HEADING']

    @property
    def ACCURATE(self):
        """Message constant 'ACCURATE'."""
        return Metaclass_SystemStatus.__constants['ACCURATE']

    @property
    def DEFAULT(self):
        """Message constant 'DEFAULT'."""
        return Metaclass_SystemStatus.__constants['DEFAULT']

    @property
    def MAPPING(self):
        """Message constant 'MAPPING'."""
        return Metaclass_SystemStatus.__constants['MAPPING']

    @property
    def MULTIMAP(self):
        """Message constant 'MULTIMAP'."""
        return Metaclass_SystemStatus.__constants['MULTIMAP']

    @property
    def IS_OPERATIONAL__DEFAULT(cls):
        """Return default value for message field 'is_operational'."""
        return False

    @property
    def BEHAVIOR_STATUS__DEFAULT(cls):
        """Return default value for message field 'behavior_status'."""
        return 'No information yet.'

    @property
    def POSITION_ACCURACY_STATUS__DEFAULT(cls):
        """Return default value for message field 'position_accuracy_status'."""
        return 'unknown'

    @property
    def SCHEDULING_ENABLED__DEFAULT(cls):
        """Return default value for message field 'scheduling_enabled'."""
        return False

    @property
    def MODE_OF_OPERATION__DEFAULT(cls):
        """Return default value for message field 'mode_of_operation'."""
        return 'default'


class SystemStatus(metaclass=Metaclass_SystemStatus):
    """
    Message class 'SystemStatus'.

    Constants:
      UNKNOWN
      INACCURATE_POSITION
      INACCURATE_HEADING
      ACCURATE
      DEFAULT
      MAPPING
      MULTIMAP
    """

    __slots__ = [
        '_is_operational',
        '_behavior_status',
        '_position_accuracy_status',
        '_scheduling_enabled',
        '_mode_of_operation',
    ]

    _fields_and_field_types = {
        'is_operational': 'boolean',
        'behavior_status': 'string',
        'position_accuracy_status': 'string',
        'scheduling_enabled': 'boolean',
        'mode_of_operation': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.is_operational = kwargs.get(
            'is_operational', SystemStatus.IS_OPERATIONAL__DEFAULT)
        self.behavior_status = kwargs.get(
            'behavior_status', SystemStatus.BEHAVIOR_STATUS__DEFAULT)
        self.position_accuracy_status = kwargs.get(
            'position_accuracy_status', SystemStatus.POSITION_ACCURACY_STATUS__DEFAULT)
        self.scheduling_enabled = kwargs.get(
            'scheduling_enabled', SystemStatus.SCHEDULING_ENABLED__DEFAULT)
        self.mode_of_operation = kwargs.get(
            'mode_of_operation', SystemStatus.MODE_OF_OPERATION__DEFAULT)

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.is_operational != other.is_operational:
            return False
        if self.behavior_status != other.behavior_status:
            return False
        if self.position_accuracy_status != other.position_accuracy_status:
            return False
        if self.scheduling_enabled != other.scheduling_enabled:
            return False
        if self.mode_of_operation != other.mode_of_operation:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def is_operational(self):
        """Message field 'is_operational'."""
        return self._is_operational

    @is_operational.setter
    def is_operational(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_operational' field must be of type 'bool'"
        self._is_operational = value

    @builtins.property
    def behavior_status(self):
        """Message field 'behavior_status'."""
        return self._behavior_status

    @behavior_status.setter
    def behavior_status(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'behavior_status' field must be of type 'str'"
        self._behavior_status = value

    @builtins.property
    def position_accuracy_status(self):
        """Message field 'position_accuracy_status'."""
        return self._position_accuracy_status

    @position_accuracy_status.setter
    def position_accuracy_status(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'position_accuracy_status' field must be of type 'str'"
        self._position_accuracy_status = value

    @builtins.property
    def scheduling_enabled(self):
        """Message field 'scheduling_enabled'."""
        return self._scheduling_enabled

    @scheduling_enabled.setter
    def scheduling_enabled(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'scheduling_enabled' field must be of type 'bool'"
        self._scheduling_enabled = value

    @builtins.property
    def mode_of_operation(self):
        """Message field 'mode_of_operation'."""
        return self._mode_of_operation

    @mode_of_operation.setter
    def mode_of_operation(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'mode_of_operation' field must be of type 'str'"
        self._mode_of_operation = value
