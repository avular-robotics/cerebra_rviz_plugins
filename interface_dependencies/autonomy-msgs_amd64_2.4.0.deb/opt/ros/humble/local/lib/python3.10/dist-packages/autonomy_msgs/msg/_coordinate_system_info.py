# generated from rosidl_generator_py/resource/_idl.py.em
# with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_CoordinateSystemInfo(type):
    """Metaclass of message 'CoordinateSystemInfo'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'LOCAL_RELATIVE': 0,
        'LOCAL_TANGENT_PLANE': 1,
        'UTM': 2,
        'UNKNOWN': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('autonomy_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'autonomy_msgs.msg.CoordinateSystemInfo')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__coordinate_system_info
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__coordinate_system_info
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__coordinate_system_info
            cls._TYPE_SUPPORT = module.type_support_msg__msg__coordinate_system_info
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__coordinate_system_info

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'LOCAL_RELATIVE': cls.__constants['LOCAL_RELATIVE'],
            'LOCAL_TANGENT_PLANE': cls.__constants['LOCAL_TANGENT_PLANE'],
            'UTM': cls.__constants['UTM'],
            'UNKNOWN': cls.__constants['UNKNOWN'],
            'TYPE__DEFAULT': 3,
            'ZONE__DEFAULT': -1,
            'NORTH__DEFAULT': True,
        }

    @property
    def LOCAL_RELATIVE(self):
        """Message constant 'LOCAL_RELATIVE'."""
        return Metaclass_CoordinateSystemInfo.__constants['LOCAL_RELATIVE']

    @property
    def LOCAL_TANGENT_PLANE(self):
        """Message constant 'LOCAL_TANGENT_PLANE'."""
        return Metaclass_CoordinateSystemInfo.__constants['LOCAL_TANGENT_PLANE']

    @property
    def UTM(self):
        """Message constant 'UTM'."""
        return Metaclass_CoordinateSystemInfo.__constants['UTM']

    @property
    def UNKNOWN(self):
        """Message constant 'UNKNOWN'."""
        return Metaclass_CoordinateSystemInfo.__constants['UNKNOWN']

    @property
    def TYPE__DEFAULT(cls):
        """Return default value for message field 'type'."""
        return 3

    @property
    def ZONE__DEFAULT(cls):
        """Return default value for message field 'zone'."""
        return -1

    @property
    def NORTH__DEFAULT(cls):
        """Return default value for message field 'north'."""
        return True


class CoordinateSystemInfo(metaclass=Metaclass_CoordinateSystemInfo):
    """
    Message class 'CoordinateSystemInfo'.

    Constants:
      LOCAL_RELATIVE
      LOCAL_TANGENT_PLANE
      UTM
      UNKNOWN
    """

    __slots__ = [
        '_type',
        '_map_name',
        '_latitude',
        '_longitude',
        '_altitude',
        '_zone',
        '_north',
        '_x_offset',
        '_y_offset',
        '_z_offset',
    ]

    _fields_and_field_types = {
        'type': 'uint8',
        'map_name': 'string',
        'latitude': 'double',
        'longitude': 'double',
        'altitude': 'double',
        'zone': 'int8',
        'north': 'boolean',
        'x_offset': 'double',
        'y_offset': 'double',
        'z_offset': 'double',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
        rosidl_parser.definition.BasicType('double'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.type = kwargs.get(
            'type', CoordinateSystemInfo.TYPE__DEFAULT)
        self.map_name = kwargs.get('map_name', str())
        self.latitude = kwargs.get('latitude', float())
        self.longitude = kwargs.get('longitude', float())
        self.altitude = kwargs.get('altitude', float())
        self.zone = kwargs.get(
            'zone', CoordinateSystemInfo.ZONE__DEFAULT)
        self.north = kwargs.get(
            'north', CoordinateSystemInfo.NORTH__DEFAULT)
        self.x_offset = kwargs.get('x_offset', float())
        self.y_offset = kwargs.get('y_offset', float())
        self.z_offset = kwargs.get('z_offset', float())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.type != other.type:
            return False
        if self.map_name != other.map_name:
            return False
        if self.latitude != other.latitude:
            return False
        if self.longitude != other.longitude:
            return False
        if self.altitude != other.altitude:
            return False
        if self.zone != other.zone:
            return False
        if self.north != other.north:
            return False
        if self.x_offset != other.x_offset:
            return False
        if self.y_offset != other.y_offset:
            return False
        if self.z_offset != other.z_offset:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property  # noqa: A003
    def type(self):  # noqa: A003
        """Message field 'type'."""
        return self._type

    @type.setter  # noqa: A003
    def type(self, value):  # noqa: A003
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'type' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'type' field must be an unsigned integer in [0, 255]"
        self._type = value

    @builtins.property
    def map_name(self):
        """Message field 'map_name'."""
        return self._map_name

    @map_name.setter
    def map_name(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'map_name' field must be of type 'str'"
        self._map_name = value

    @builtins.property
    def latitude(self):
        """Message field 'latitude'."""
        return self._latitude

    @latitude.setter
    def latitude(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'latitude' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'latitude' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._latitude = value

    @builtins.property
    def longitude(self):
        """Message field 'longitude'."""
        return self._longitude

    @longitude.setter
    def longitude(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'longitude' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'longitude' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._longitude = value

    @builtins.property
    def altitude(self):
        """Message field 'altitude'."""
        return self._altitude

    @altitude.setter
    def altitude(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'altitude' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'altitude' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._altitude = value

    @builtins.property
    def zone(self):
        """Message field 'zone'."""
        return self._zone

    @zone.setter
    def zone(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'zone' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'zone' field must be an integer in [-128, 127]"
        self._zone = value

    @builtins.property
    def north(self):
        """Message field 'north'."""
        return self._north

    @north.setter
    def north(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'north' field must be of type 'bool'"
        self._north = value

    @builtins.property
    def x_offset(self):
        """Message field 'x_offset'."""
        return self._x_offset

    @x_offset.setter
    def x_offset(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'x_offset' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'x_offset' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._x_offset = value

    @builtins.property
    def y_offset(self):
        """Message field 'y_offset'."""
        return self._y_offset

    @y_offset.setter
    def y_offset(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'y_offset' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'y_offset' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._y_offset = value

    @builtins.property
    def z_offset(self):
        """Message field 'z_offset'."""
        return self._z_offset

    @z_offset.setter
    def z_offset(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'z_offset' field must be of type 'float'"
            assert not (value < -1.7976931348623157e+308 or value > 1.7976931348623157e+308) or math.isinf(value), \
                "The 'z_offset' field must be a double in [-1.7976931348623157e+308, 1.7976931348623157e+308]"
        self._z_offset = value
