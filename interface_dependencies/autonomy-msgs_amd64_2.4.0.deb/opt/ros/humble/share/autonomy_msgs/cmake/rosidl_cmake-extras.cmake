# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(autonomy_msgs_IDL_FILES "srv/GetState.idl;srv/SetCoordinateSystem.idl;srv/SetState.idl;srv/Trigger.idl;msg/CoordinateSystemInfo.idl;msg/GridMap2D.idl;msg/Path.idl;msg/Polygon.idl;msg/PoseWithTwist.idl;msg/StatusString.idl;msg/SystemStatus.idl")
set(autonomy_msgs_INTERFACE_FILES "srv/GetState.srv;srv/GetState_Request.msg;srv/GetState_Response.msg;srv/SetCoordinateSystem.srv;srv/SetCoordinateSystem_Request.msg;srv/SetCoordinateSystem_Response.msg;srv/SetState.srv;srv/SetState_Request.msg;srv/SetState_Response.msg;srv/Trigger.srv;srv/Trigger_Request.msg;srv/Trigger_Response.msg;msg/CoordinateSystemInfo.msg;msg/GridMap2D.msg;msg/Path.msg;msg/Polygon.msg;msg/PoseWithTwist.msg;msg/StatusString.msg;msg/SystemStatus.msg")
