// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__STATUS_STRING_HPP_
#define AUTONOMY_MSGS__MSG__STATUS_STRING_HPP_

#include "autonomy_msgs/msg/detail/status_string__struct.hpp"
#include "autonomy_msgs/msg/detail/status_string__builder.hpp"
#include "autonomy_msgs/msg/detail/status_string__traits.hpp"
#include "autonomy_msgs/msg/detail/status_string__type_support.hpp"

#endif  // AUTONOMY_MSGS__MSG__STATUS_STRING_HPP_
