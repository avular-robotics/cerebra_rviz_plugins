// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TYPE_SUPPORT_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "autonomy_msgs/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_autonomy_msgs
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  autonomy_msgs,
  msg,
  SystemStatus
)();
#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TYPE_SUPPORT_HPP_
