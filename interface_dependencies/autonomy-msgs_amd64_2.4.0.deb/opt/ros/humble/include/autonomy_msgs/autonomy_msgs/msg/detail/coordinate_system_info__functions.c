// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/coordinate_system_info__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `map_name`
#include "rosidl_runtime_c/string_functions.h"

bool
autonomy_msgs__msg__CoordinateSystemInfo__init(autonomy_msgs__msg__CoordinateSystemInfo * msg)
{
  if (!msg) {
    return false;
  }
  // type
  msg->type = 3;
  // map_name
  if (!rosidl_runtime_c__String__init(&msg->map_name)) {
    autonomy_msgs__msg__CoordinateSystemInfo__fini(msg);
    return false;
  }
  // latitude
  // longitude
  // altitude
  // zone
  msg->zone = -1;
  // north
  msg->north = true;
  // x_offset
  // y_offset
  // z_offset
  return true;
}

void
autonomy_msgs__msg__CoordinateSystemInfo__fini(autonomy_msgs__msg__CoordinateSystemInfo * msg)
{
  if (!msg) {
    return;
  }
  // type
  // map_name
  rosidl_runtime_c__String__fini(&msg->map_name);
  // latitude
  // longitude
  // altitude
  // zone
  // north
  // x_offset
  // y_offset
  // z_offset
}

bool
autonomy_msgs__msg__CoordinateSystemInfo__are_equal(const autonomy_msgs__msg__CoordinateSystemInfo * lhs, const autonomy_msgs__msg__CoordinateSystemInfo * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // type
  if (lhs->type != rhs->type) {
    return false;
  }
  // map_name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->map_name), &(rhs->map_name)))
  {
    return false;
  }
  // latitude
  if (lhs->latitude != rhs->latitude) {
    return false;
  }
  // longitude
  if (lhs->longitude != rhs->longitude) {
    return false;
  }
  // altitude
  if (lhs->altitude != rhs->altitude) {
    return false;
  }
  // zone
  if (lhs->zone != rhs->zone) {
    return false;
  }
  // north
  if (lhs->north != rhs->north) {
    return false;
  }
  // x_offset
  if (lhs->x_offset != rhs->x_offset) {
    return false;
  }
  // y_offset
  if (lhs->y_offset != rhs->y_offset) {
    return false;
  }
  // z_offset
  if (lhs->z_offset != rhs->z_offset) {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__CoordinateSystemInfo__copy(
  const autonomy_msgs__msg__CoordinateSystemInfo * input,
  autonomy_msgs__msg__CoordinateSystemInfo * output)
{
  if (!input || !output) {
    return false;
  }
  // type
  output->type = input->type;
  // map_name
  if (!rosidl_runtime_c__String__copy(
      &(input->map_name), &(output->map_name)))
  {
    return false;
  }
  // latitude
  output->latitude = input->latitude;
  // longitude
  output->longitude = input->longitude;
  // altitude
  output->altitude = input->altitude;
  // zone
  output->zone = input->zone;
  // north
  output->north = input->north;
  // x_offset
  output->x_offset = input->x_offset;
  // y_offset
  output->y_offset = input->y_offset;
  // z_offset
  output->z_offset = input->z_offset;
  return true;
}

autonomy_msgs__msg__CoordinateSystemInfo *
autonomy_msgs__msg__CoordinateSystemInfo__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__CoordinateSystemInfo * msg = (autonomy_msgs__msg__CoordinateSystemInfo *)allocator.allocate(sizeof(autonomy_msgs__msg__CoordinateSystemInfo), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__CoordinateSystemInfo));
  bool success = autonomy_msgs__msg__CoordinateSystemInfo__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__CoordinateSystemInfo__destroy(autonomy_msgs__msg__CoordinateSystemInfo * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__CoordinateSystemInfo__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__init(autonomy_msgs__msg__CoordinateSystemInfo__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__CoordinateSystemInfo * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__CoordinateSystemInfo *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__CoordinateSystemInfo), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__CoordinateSystemInfo__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__CoordinateSystemInfo__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__fini(autonomy_msgs__msg__CoordinateSystemInfo__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__CoordinateSystemInfo__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__CoordinateSystemInfo__Sequence *
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__CoordinateSystemInfo__Sequence * array = (autonomy_msgs__msg__CoordinateSystemInfo__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__CoordinateSystemInfo__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__CoordinateSystemInfo__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__destroy(autonomy_msgs__msg__CoordinateSystemInfo__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__CoordinateSystemInfo__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__are_equal(const autonomy_msgs__msg__CoordinateSystemInfo__Sequence * lhs, const autonomy_msgs__msg__CoordinateSystemInfo__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__CoordinateSystemInfo__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__CoordinateSystemInfo__Sequence__copy(
  const autonomy_msgs__msg__CoordinateSystemInfo__Sequence * input,
  autonomy_msgs__msg__CoordinateSystemInfo__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__CoordinateSystemInfo);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__CoordinateSystemInfo * data =
      (autonomy_msgs__msg__CoordinateSystemInfo *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__CoordinateSystemInfo__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__CoordinateSystemInfo__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__CoordinateSystemInfo__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
