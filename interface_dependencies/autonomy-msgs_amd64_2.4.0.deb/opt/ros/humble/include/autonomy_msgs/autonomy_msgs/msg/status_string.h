// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__STATUS_STRING_H_
#define AUTONOMY_MSGS__MSG__STATUS_STRING_H_

#include "autonomy_msgs/msg/detail/status_string__struct.h"
#include "autonomy_msgs/msg/detail/status_string__functions.h"
#include "autonomy_msgs/msg/detail/status_string__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__STATUS_STRING_H_
