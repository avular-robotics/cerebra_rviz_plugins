// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/Polygon.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/polygon__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `uuid`
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `info`
#include "autonomy_msgs/msg/detail/coordinate_system_info__functions.h"
// Member `points`
#include "geometry_msgs/msg/detail/point__functions.h"

bool
autonomy_msgs__msg__Polygon__init(autonomy_msgs__msg__Polygon * msg)
{
  if (!msg) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__init(&msg->uuid)) {
    autonomy_msgs__msg__Polygon__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    autonomy_msgs__msg__Polygon__fini(msg);
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__init(&msg->info)) {
    autonomy_msgs__msg__Polygon__fini(msg);
    return false;
  }
  // points
  if (!geometry_msgs__msg__Point__Sequence__init(&msg->points, 0)) {
    autonomy_msgs__msg__Polygon__fini(msg);
    return false;
  }
  // right_sided
  msg->right_sided = true;
  return true;
}

void
autonomy_msgs__msg__Polygon__fini(autonomy_msgs__msg__Polygon * msg)
{
  if (!msg) {
    return;
  }
  // uuid
  rosidl_runtime_c__String__fini(&msg->uuid);
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // info
  autonomy_msgs__msg__CoordinateSystemInfo__fini(&msg->info);
  // points
  geometry_msgs__msg__Point__Sequence__fini(&msg->points);
  // right_sided
}

bool
autonomy_msgs__msg__Polygon__are_equal(const autonomy_msgs__msg__Polygon * lhs, const autonomy_msgs__msg__Polygon * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->uuid), &(rhs->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // points
  if (!geometry_msgs__msg__Point__Sequence__are_equal(
      &(lhs->points), &(rhs->points)))
  {
    return false;
  }
  // right_sided
  if (lhs->right_sided != rhs->right_sided) {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__Polygon__copy(
  const autonomy_msgs__msg__Polygon * input,
  autonomy_msgs__msg__Polygon * output)
{
  if (!input || !output) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__copy(
      &(input->uuid), &(output->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // points
  if (!geometry_msgs__msg__Point__Sequence__copy(
      &(input->points), &(output->points)))
  {
    return false;
  }
  // right_sided
  output->right_sided = input->right_sided;
  return true;
}

autonomy_msgs__msg__Polygon *
autonomy_msgs__msg__Polygon__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Polygon * msg = (autonomy_msgs__msg__Polygon *)allocator.allocate(sizeof(autonomy_msgs__msg__Polygon), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__Polygon));
  bool success = autonomy_msgs__msg__Polygon__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__Polygon__destroy(autonomy_msgs__msg__Polygon * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__Polygon__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__Polygon__Sequence__init(autonomy_msgs__msg__Polygon__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Polygon * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__Polygon *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__Polygon), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__Polygon__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__Polygon__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__Polygon__Sequence__fini(autonomy_msgs__msg__Polygon__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__Polygon__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__Polygon__Sequence *
autonomy_msgs__msg__Polygon__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Polygon__Sequence * array = (autonomy_msgs__msg__Polygon__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__Polygon__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__Polygon__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__Polygon__Sequence__destroy(autonomy_msgs__msg__Polygon__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__Polygon__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__Polygon__Sequence__are_equal(const autonomy_msgs__msg__Polygon__Sequence * lhs, const autonomy_msgs__msg__Polygon__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__Polygon__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__Polygon__Sequence__copy(
  const autonomy_msgs__msg__Polygon__Sequence * input,
  autonomy_msgs__msg__Polygon__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__Polygon);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__Polygon * data =
      (autonomy_msgs__msg__Polygon *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__Polygon__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__Polygon__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__Polygon__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
