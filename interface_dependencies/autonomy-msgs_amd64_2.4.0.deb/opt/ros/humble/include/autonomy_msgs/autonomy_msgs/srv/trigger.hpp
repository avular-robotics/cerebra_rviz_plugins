// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__TRIGGER_HPP_
#define AUTONOMY_MSGS__SRV__TRIGGER_HPP_

#include "autonomy_msgs/srv/detail/trigger__struct.hpp"
#include "autonomy_msgs/srv/detail/trigger__builder.hpp"
#include "autonomy_msgs/srv/detail/trigger__traits.hpp"
#include "autonomy_msgs/srv/detail/trigger__type_support.hpp"

#endif  // AUTONOMY_MSGS__SRV__TRIGGER_HPP_
