// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__TRAITS_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autonomy_msgs/msg/detail/status_string__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace autonomy_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const StatusString & msg,
  std::ostream & out)
{
  out << "{";
  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const StatusString & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const StatusString & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::msg::StatusString & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::msg::StatusString & msg)
{
  return autonomy_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::msg::StatusString>()
{
  return "autonomy_msgs::msg::StatusString";
}

template<>
inline const char * name<autonomy_msgs::msg::StatusString>()
{
  return "autonomy_msgs/msg/StatusString";
}

template<>
struct has_fixed_size<autonomy_msgs::msg::StatusString>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::msg::StatusString>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::msg::StatusString>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__TRAITS_HPP_
