// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_CoordinateSystemInfo_z_offset
{
public:
  explicit Init_CoordinateSystemInfo_z_offset(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::CoordinateSystemInfo z_offset(::autonomy_msgs::msg::CoordinateSystemInfo::_z_offset_type arg)
  {
    msg_.z_offset = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_y_offset
{
public:
  explicit Init_CoordinateSystemInfo_y_offset(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_z_offset y_offset(::autonomy_msgs::msg::CoordinateSystemInfo::_y_offset_type arg)
  {
    msg_.y_offset = std::move(arg);
    return Init_CoordinateSystemInfo_z_offset(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_x_offset
{
public:
  explicit Init_CoordinateSystemInfo_x_offset(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_y_offset x_offset(::autonomy_msgs::msg::CoordinateSystemInfo::_x_offset_type arg)
  {
    msg_.x_offset = std::move(arg);
    return Init_CoordinateSystemInfo_y_offset(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_north
{
public:
  explicit Init_CoordinateSystemInfo_north(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_x_offset north(::autonomy_msgs::msg::CoordinateSystemInfo::_north_type arg)
  {
    msg_.north = std::move(arg);
    return Init_CoordinateSystemInfo_x_offset(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_zone
{
public:
  explicit Init_CoordinateSystemInfo_zone(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_north zone(::autonomy_msgs::msg::CoordinateSystemInfo::_zone_type arg)
  {
    msg_.zone = std::move(arg);
    return Init_CoordinateSystemInfo_north(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_altitude
{
public:
  explicit Init_CoordinateSystemInfo_altitude(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_zone altitude(::autonomy_msgs::msg::CoordinateSystemInfo::_altitude_type arg)
  {
    msg_.altitude = std::move(arg);
    return Init_CoordinateSystemInfo_zone(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_longitude
{
public:
  explicit Init_CoordinateSystemInfo_longitude(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_altitude longitude(::autonomy_msgs::msg::CoordinateSystemInfo::_longitude_type arg)
  {
    msg_.longitude = std::move(arg);
    return Init_CoordinateSystemInfo_altitude(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_latitude
{
public:
  explicit Init_CoordinateSystemInfo_latitude(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_longitude latitude(::autonomy_msgs::msg::CoordinateSystemInfo::_latitude_type arg)
  {
    msg_.latitude = std::move(arg);
    return Init_CoordinateSystemInfo_longitude(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_map_name
{
public:
  explicit Init_CoordinateSystemInfo_map_name(::autonomy_msgs::msg::CoordinateSystemInfo & msg)
  : msg_(msg)
  {}
  Init_CoordinateSystemInfo_latitude map_name(::autonomy_msgs::msg::CoordinateSystemInfo::_map_name_type arg)
  {
    msg_.map_name = std::move(arg);
    return Init_CoordinateSystemInfo_latitude(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

class Init_CoordinateSystemInfo_type
{
public:
  Init_CoordinateSystemInfo_type()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_CoordinateSystemInfo_map_name type(::autonomy_msgs::msg::CoordinateSystemInfo::_type_type arg)
  {
    msg_.type = std::move(arg);
    return Init_CoordinateSystemInfo_map_name(msg_);
  }

private:
  ::autonomy_msgs::msg::CoordinateSystemInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::CoordinateSystemInfo>()
{
  return autonomy_msgs::msg::builder::Init_CoordinateSystemInfo_type();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__BUILDER_HPP_
