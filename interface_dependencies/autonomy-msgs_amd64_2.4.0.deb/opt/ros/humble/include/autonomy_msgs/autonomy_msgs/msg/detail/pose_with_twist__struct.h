// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/PoseWithTwist.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'twist'
#include "geometry_msgs/msg/detail/twist__struct.h"

/// Struct defined in msg/PoseWithTwist in the package autonomy_msgs.
typedef struct autonomy_msgs__msg__PoseWithTwist
{
  geometry_msgs__msg__Pose pose;
  geometry_msgs__msg__Twist twist;
} autonomy_msgs__msg__PoseWithTwist;

// Struct for a sequence of autonomy_msgs__msg__PoseWithTwist.
typedef struct autonomy_msgs__msg__PoseWithTwist__Sequence
{
  autonomy_msgs__msg__PoseWithTwist * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__PoseWithTwist__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__STRUCT_H_
