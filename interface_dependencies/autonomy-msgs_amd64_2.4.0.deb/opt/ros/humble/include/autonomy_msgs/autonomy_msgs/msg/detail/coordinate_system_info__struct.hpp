// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__msg__CoordinateSystemInfo __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__msg__CoordinateSystemInfo __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct CoordinateSystemInfo_
{
  using Type = CoordinateSystemInfo_<ContainerAllocator>;

  explicit CoordinateSystemInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->type = 3;
      this->zone = -1;
      this->north = true;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->type = 0;
      this->map_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->zone = 0;
      this->north = false;
      this->x_offset = 0.0;
      this->y_offset = 0.0;
      this->z_offset = 0.0;
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->map_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->x_offset = 0.0;
      this->y_offset = 0.0;
      this->z_offset = 0.0;
    }
  }

  explicit CoordinateSystemInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : map_name(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->type = 3;
      this->zone = -1;
      this->north = true;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->type = 0;
      this->map_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->zone = 0;
      this->north = false;
      this->x_offset = 0.0;
      this->y_offset = 0.0;
      this->z_offset = 0.0;
    }
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->map_name = "";
      this->latitude = 0.0;
      this->longitude = 0.0;
      this->altitude = 0.0;
      this->x_offset = 0.0;
      this->y_offset = 0.0;
      this->z_offset = 0.0;
    }
  }

  // field types and members
  using _type_type =
    uint8_t;
  _type_type type;
  using _map_name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _map_name_type map_name;
  using _latitude_type =
    double;
  _latitude_type latitude;
  using _longitude_type =
    double;
  _longitude_type longitude;
  using _altitude_type =
    double;
  _altitude_type altitude;
  using _zone_type =
    int8_t;
  _zone_type zone;
  using _north_type =
    bool;
  _north_type north;
  using _x_offset_type =
    double;
  _x_offset_type x_offset;
  using _y_offset_type =
    double;
  _y_offset_type y_offset;
  using _z_offset_type =
    double;
  _z_offset_type z_offset;

  // setters for named parameter idiom
  Type & set__type(
    const uint8_t & _arg)
  {
    this->type = _arg;
    return *this;
  }
  Type & set__map_name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->map_name = _arg;
    return *this;
  }
  Type & set__latitude(
    const double & _arg)
  {
    this->latitude = _arg;
    return *this;
  }
  Type & set__longitude(
    const double & _arg)
  {
    this->longitude = _arg;
    return *this;
  }
  Type & set__altitude(
    const double & _arg)
  {
    this->altitude = _arg;
    return *this;
  }
  Type & set__zone(
    const int8_t & _arg)
  {
    this->zone = _arg;
    return *this;
  }
  Type & set__north(
    const bool & _arg)
  {
    this->north = _arg;
    return *this;
  }
  Type & set__x_offset(
    const double & _arg)
  {
    this->x_offset = _arg;
    return *this;
  }
  Type & set__y_offset(
    const double & _arg)
  {
    this->y_offset = _arg;
    return *this;
  }
  Type & set__z_offset(
    const double & _arg)
  {
    this->z_offset = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint8_t LOCAL_RELATIVE =
    0u;
  static constexpr uint8_t LOCAL_TANGENT_PLANE =
    1u;
  static constexpr uint8_t UTM =
    2u;
  static constexpr uint8_t UNKNOWN =
    3u;

  // pointer types
  using RawPtr =
    autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__msg__CoordinateSystemInfo
    std::shared_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__msg__CoordinateSystemInfo
    std::shared_ptr<autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const CoordinateSystemInfo_ & other) const
  {
    if (this->type != other.type) {
      return false;
    }
    if (this->map_name != other.map_name) {
      return false;
    }
    if (this->latitude != other.latitude) {
      return false;
    }
    if (this->longitude != other.longitude) {
      return false;
    }
    if (this->altitude != other.altitude) {
      return false;
    }
    if (this->zone != other.zone) {
      return false;
    }
    if (this->north != other.north) {
      return false;
    }
    if (this->x_offset != other.x_offset) {
      return false;
    }
    if (this->y_offset != other.y_offset) {
      return false;
    }
    if (this->z_offset != other.z_offset) {
      return false;
    }
    return true;
  }
  bool operator!=(const CoordinateSystemInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct CoordinateSystemInfo_

// alias to use template instance with default allocator
using CoordinateSystemInfo =
  autonomy_msgs::msg::CoordinateSystemInfo_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t CoordinateSystemInfo_<ContainerAllocator>::LOCAL_RELATIVE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t CoordinateSystemInfo_<ContainerAllocator>::LOCAL_TANGENT_PLANE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t CoordinateSystemInfo_<ContainerAllocator>::UTM;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t CoordinateSystemInfo_<ContainerAllocator>::UNKNOWN;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_HPP_
