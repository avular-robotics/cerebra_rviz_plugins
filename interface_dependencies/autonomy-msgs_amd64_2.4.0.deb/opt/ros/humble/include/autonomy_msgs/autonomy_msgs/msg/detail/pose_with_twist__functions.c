// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/PoseWithTwist.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/pose_with_twist__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `twist`
#include "geometry_msgs/msg/detail/twist__functions.h"

bool
autonomy_msgs__msg__PoseWithTwist__init(autonomy_msgs__msg__PoseWithTwist * msg)
{
  if (!msg) {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    autonomy_msgs__msg__PoseWithTwist__fini(msg);
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__init(&msg->twist)) {
    autonomy_msgs__msg__PoseWithTwist__fini(msg);
    return false;
  }
  return true;
}

void
autonomy_msgs__msg__PoseWithTwist__fini(autonomy_msgs__msg__PoseWithTwist * msg)
{
  if (!msg) {
    return;
  }
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // twist
  geometry_msgs__msg__Twist__fini(&msg->twist);
}

bool
autonomy_msgs__msg__PoseWithTwist__are_equal(const autonomy_msgs__msg__PoseWithTwist * lhs, const autonomy_msgs__msg__PoseWithTwist * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__are_equal(
      &(lhs->pose), &(rhs->pose)))
  {
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__are_equal(
      &(lhs->twist), &(rhs->twist)))
  {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__PoseWithTwist__copy(
  const autonomy_msgs__msg__PoseWithTwist * input,
  autonomy_msgs__msg__PoseWithTwist * output)
{
  if (!input || !output) {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__copy(
      &(input->pose), &(output->pose)))
  {
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__copy(
      &(input->twist), &(output->twist)))
  {
    return false;
  }
  return true;
}

autonomy_msgs__msg__PoseWithTwist *
autonomy_msgs__msg__PoseWithTwist__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__PoseWithTwist * msg = (autonomy_msgs__msg__PoseWithTwist *)allocator.allocate(sizeof(autonomy_msgs__msg__PoseWithTwist), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__PoseWithTwist));
  bool success = autonomy_msgs__msg__PoseWithTwist__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__PoseWithTwist__destroy(autonomy_msgs__msg__PoseWithTwist * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__PoseWithTwist__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__PoseWithTwist__Sequence__init(autonomy_msgs__msg__PoseWithTwist__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__PoseWithTwist * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__PoseWithTwist *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__PoseWithTwist), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__PoseWithTwist__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__PoseWithTwist__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__PoseWithTwist__Sequence__fini(autonomy_msgs__msg__PoseWithTwist__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__PoseWithTwist__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__PoseWithTwist__Sequence *
autonomy_msgs__msg__PoseWithTwist__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__PoseWithTwist__Sequence * array = (autonomy_msgs__msg__PoseWithTwist__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__PoseWithTwist__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__PoseWithTwist__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__PoseWithTwist__Sequence__destroy(autonomy_msgs__msg__PoseWithTwist__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__PoseWithTwist__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__PoseWithTwist__Sequence__are_equal(const autonomy_msgs__msg__PoseWithTwist__Sequence * lhs, const autonomy_msgs__msg__PoseWithTwist__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__PoseWithTwist__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__PoseWithTwist__Sequence__copy(
  const autonomy_msgs__msg__PoseWithTwist__Sequence * input,
  autonomy_msgs__msg__PoseWithTwist__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__PoseWithTwist);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__PoseWithTwist * data =
      (autonomy_msgs__msg__PoseWithTwist *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__PoseWithTwist__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__PoseWithTwist__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__PoseWithTwist__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
