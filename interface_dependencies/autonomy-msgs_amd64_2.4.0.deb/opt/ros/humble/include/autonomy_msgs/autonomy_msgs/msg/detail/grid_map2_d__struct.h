// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/GridMap2D.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'uuid'
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'map'
#include "nav_msgs/msg/detail/occupancy_grid__struct.h"

/// Struct defined in msg/GridMap2D in the package autonomy_msgs.
/**
  * Unique generated id
 */
typedef struct autonomy_msgs__msg__GridMap2D
{
  rosidl_runtime_c__String uuid;
  /// Human readable name
  rosidl_runtime_c__String name;
  nav_msgs__msg__OccupancyGrid map;
} autonomy_msgs__msg__GridMap2D;

// Struct for a sequence of autonomy_msgs__msg__GridMap2D.
typedef struct autonomy_msgs__msg__GridMap2D__Sequence
{
  autonomy_msgs__msg__GridMap2D * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__GridMap2D__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_H_
