// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/Path.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__PATH__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__PATH__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/path__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_Path_poses
{
public:
  explicit Init_Path_poses(::autonomy_msgs::msg::Path & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::Path poses(::autonomy_msgs::msg::Path::_poses_type arg)
  {
    msg_.poses = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::Path msg_;
};

class Init_Path_info
{
public:
  explicit Init_Path_info(::autonomy_msgs::msg::Path & msg)
  : msg_(msg)
  {}
  Init_Path_poses info(::autonomy_msgs::msg::Path::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_Path_poses(msg_);
  }

private:
  ::autonomy_msgs::msg::Path msg_;
};

class Init_Path_header
{
public:
  explicit Init_Path_header(::autonomy_msgs::msg::Path & msg)
  : msg_(msg)
  {}
  Init_Path_info header(::autonomy_msgs::msg::Path::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_Path_info(msg_);
  }

private:
  ::autonomy_msgs::msg::Path msg_;
};

class Init_Path_name
{
public:
  explicit Init_Path_name(::autonomy_msgs::msg::Path & msg)
  : msg_(msg)
  {}
  Init_Path_header name(::autonomy_msgs::msg::Path::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_Path_header(msg_);
  }

private:
  ::autonomy_msgs::msg::Path msg_;
};

class Init_Path_uuid
{
public:
  Init_Path_uuid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Path_name uuid(::autonomy_msgs::msg::Path::_uuid_type arg)
  {
    msg_.uuid = std::move(arg);
    return Init_Path_name(msg_);
  }

private:
  ::autonomy_msgs::msg::Path msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::Path>()
{
  return autonomy_msgs::msg::builder::Init_Path_uuid();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__PATH__BUILDER_HPP_
