// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from autonomy_msgs:msg/PoseWithTwist.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "autonomy_msgs/msg/detail/pose_with_twist__rosidl_typesupport_introspection_c.h"
#include "autonomy_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "autonomy_msgs/msg/detail/pose_with_twist__functions.h"
#include "autonomy_msgs/msg/detail/pose_with_twist__struct.h"


// Include directives for member types
// Member `pose`
#include "geometry_msgs/msg/pose.h"
// Member `pose`
#include "geometry_msgs/msg/detail/pose__rosidl_typesupport_introspection_c.h"
// Member `twist`
#include "geometry_msgs/msg/twist.h"
// Member `twist`
#include "geometry_msgs/msg/detail/twist__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  autonomy_msgs__msg__PoseWithTwist__init(message_memory);
}

void autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_fini_function(void * message_memory)
{
  autonomy_msgs__msg__PoseWithTwist__fini(message_memory);
}

static rosidl_typesupport_introspection_c__MessageMember autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_member_array[2] = {
  {
    "pose",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__PoseWithTwist, pose),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "twist",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__PoseWithTwist, twist),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_members = {
  "autonomy_msgs__msg",  // message namespace
  "PoseWithTwist",  // message name
  2,  // number of fields
  sizeof(autonomy_msgs__msg__PoseWithTwist),
  autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_member_array,  // message members
  autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_init_function,  // function to initialize message memory (memory has to be allocated)
  autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_type_support_handle = {
  0,
  &autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_autonomy_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autonomy_msgs, msg, PoseWithTwist)() {
  autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_member_array[0].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Pose)();
  autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_member_array[1].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Twist)();
  if (!autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_type_support_handle.typesupport_identifier) {
    autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &autonomy_msgs__msg__PoseWithTwist__rosidl_typesupport_introspection_c__PoseWithTwist_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
