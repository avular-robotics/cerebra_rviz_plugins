// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autonomy_msgs:srv/SetCoordinateSystem.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_HPP_
#define AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'info'
#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Request __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Request __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetCoordinateSystem_Request_
{
  using Type = SetCoordinateSystem_Request_<ContainerAllocator>;

  explicit SetCoordinateSystem_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_init)
  {
    (void)_init;
  }

  explicit SetCoordinateSystem_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : info(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _info_type =
    autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator>;
  _info_type info;

  // setters for named parameter idiom
  Type & set__info(
    const autonomy_msgs::msg::CoordinateSystemInfo_<ContainerAllocator> & _arg)
  {
    this->info = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Request
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Request
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetCoordinateSystem_Request_ & other) const
  {
    if (this->info != other.info) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetCoordinateSystem_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetCoordinateSystem_Request_

// alias to use template instance with default allocator
using SetCoordinateSystem_Request =
  autonomy_msgs::srv::SetCoordinateSystem_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace autonomy_msgs


#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Response __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Response __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetCoordinateSystem_Response_
{
  using Type = SetCoordinateSystem_Response_<ContainerAllocator>;

  explicit SetCoordinateSystem_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->success = false;
      this->message = "Unexpected Error. Response message not set.";
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->success = false;
      this->message = "";
    }
  }

  explicit SetCoordinateSystem_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->success = false;
      this->message = "Unexpected Error. Response message not set.";
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Response
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__srv__SetCoordinateSystem_Response
    std::shared_ptr<autonomy_msgs::srv::SetCoordinateSystem_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetCoordinateSystem_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetCoordinateSystem_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetCoordinateSystem_Response_

// alias to use template instance with default allocator
using SetCoordinateSystem_Response =
  autonomy_msgs::srv::SetCoordinateSystem_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace autonomy_msgs

namespace autonomy_msgs
{

namespace srv
{

struct SetCoordinateSystem
{
  using Request = autonomy_msgs::srv::SetCoordinateSystem_Request;
  using Response = autonomy_msgs::srv::SetCoordinateSystem_Response;
};

}  // namespace srv

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_HPP_
