// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/Polygon.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__POLYGON__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__POLYGON__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/polygon__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_Polygon_right_sided
{
public:
  explicit Init_Polygon_right_sided(::autonomy_msgs::msg::Polygon & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::Polygon right_sided(::autonomy_msgs::msg::Polygon::_right_sided_type arg)
  {
    msg_.right_sided = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::Polygon msg_;
};

class Init_Polygon_points
{
public:
  explicit Init_Polygon_points(::autonomy_msgs::msg::Polygon & msg)
  : msg_(msg)
  {}
  Init_Polygon_right_sided points(::autonomy_msgs::msg::Polygon::_points_type arg)
  {
    msg_.points = std::move(arg);
    return Init_Polygon_right_sided(msg_);
  }

private:
  ::autonomy_msgs::msg::Polygon msg_;
};

class Init_Polygon_info
{
public:
  explicit Init_Polygon_info(::autonomy_msgs::msg::Polygon & msg)
  : msg_(msg)
  {}
  Init_Polygon_points info(::autonomy_msgs::msg::Polygon::_info_type arg)
  {
    msg_.info = std::move(arg);
    return Init_Polygon_points(msg_);
  }

private:
  ::autonomy_msgs::msg::Polygon msg_;
};

class Init_Polygon_name
{
public:
  explicit Init_Polygon_name(::autonomy_msgs::msg::Polygon & msg)
  : msg_(msg)
  {}
  Init_Polygon_info name(::autonomy_msgs::msg::Polygon::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_Polygon_info(msg_);
  }

private:
  ::autonomy_msgs::msg::Polygon msg_;
};

class Init_Polygon_uuid
{
public:
  Init_Polygon_uuid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Polygon_name uuid(::autonomy_msgs::msg::Polygon::_uuid_type arg)
  {
    msg_.uuid = std::move(arg);
    return Init_Polygon_name(msg_);
  }

private:
  ::autonomy_msgs::msg::Polygon msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::Polygon>()
{
  return autonomy_msgs::msg::builder::Init_Polygon_uuid();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__POLYGON__BUILDER_HPP_
