// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:srv/Trigger.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__TRIGGER_H_
#define AUTONOMY_MSGS__SRV__TRIGGER_H_

#include "autonomy_msgs/srv/detail/trigger__struct.h"
#include "autonomy_msgs/srv/detail/trigger__functions.h"
#include "autonomy_msgs/srv/detail/trigger__type_support.h"

#endif  // AUTONOMY_MSGS__SRV__TRIGGER_H_
