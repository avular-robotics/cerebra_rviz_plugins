// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/system_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemStatus_mode_of_operation
{
public:
  explicit Init_SystemStatus_mode_of_operation(::autonomy_msgs::msg::SystemStatus & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::SystemStatus mode_of_operation(::autonomy_msgs::msg::SystemStatus::_mode_of_operation_type arg)
  {
    msg_.mode_of_operation = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::SystemStatus msg_;
};

class Init_SystemStatus_scheduling_enabled
{
public:
  explicit Init_SystemStatus_scheduling_enabled(::autonomy_msgs::msg::SystemStatus & msg)
  : msg_(msg)
  {}
  Init_SystemStatus_mode_of_operation scheduling_enabled(::autonomy_msgs::msg::SystemStatus::_scheduling_enabled_type arg)
  {
    msg_.scheduling_enabled = std::move(arg);
    return Init_SystemStatus_mode_of_operation(msg_);
  }

private:
  ::autonomy_msgs::msg::SystemStatus msg_;
};

class Init_SystemStatus_position_accuracy_status
{
public:
  explicit Init_SystemStatus_position_accuracy_status(::autonomy_msgs::msg::SystemStatus & msg)
  : msg_(msg)
  {}
  Init_SystemStatus_scheduling_enabled position_accuracy_status(::autonomy_msgs::msg::SystemStatus::_position_accuracy_status_type arg)
  {
    msg_.position_accuracy_status = std::move(arg);
    return Init_SystemStatus_scheduling_enabled(msg_);
  }

private:
  ::autonomy_msgs::msg::SystemStatus msg_;
};

class Init_SystemStatus_behavior_status
{
public:
  explicit Init_SystemStatus_behavior_status(::autonomy_msgs::msg::SystemStatus & msg)
  : msg_(msg)
  {}
  Init_SystemStatus_position_accuracy_status behavior_status(::autonomy_msgs::msg::SystemStatus::_behavior_status_type arg)
  {
    msg_.behavior_status = std::move(arg);
    return Init_SystemStatus_position_accuracy_status(msg_);
  }

private:
  ::autonomy_msgs::msg::SystemStatus msg_;
};

class Init_SystemStatus_is_operational
{
public:
  Init_SystemStatus_is_operational()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemStatus_behavior_status is_operational(::autonomy_msgs::msg::SystemStatus::_is_operational_type arg)
  {
    msg_.is_operational = std::move(arg);
    return Init_SystemStatus_behavior_status(msg_);
  }

private:
  ::autonomy_msgs::msg::SystemStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::SystemStatus>()
{
  return autonomy_msgs::msg::builder::Init_SystemStatus_is_operational();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__BUILDER_HPP_
