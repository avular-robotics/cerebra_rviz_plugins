// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__SYSTEM_STATUS_HPP_
#define AUTONOMY_MSGS__MSG__SYSTEM_STATUS_HPP_

#include "autonomy_msgs/msg/detail/system_status__struct.hpp"
#include "autonomy_msgs/msg/detail/system_status__builder.hpp"
#include "autonomy_msgs/msg/detail/system_status__traits.hpp"
#include "autonomy_msgs/msg/detail/system_status__type_support.hpp"

#endif  // AUTONOMY_MSGS__MSG__SYSTEM_STATUS_HPP_
