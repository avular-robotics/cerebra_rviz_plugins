// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'status'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/StatusString in the package autonomy_msgs.
typedef struct autonomy_msgs__msg__StatusString
{
  rosidl_runtime_c__String status;
} autonomy_msgs__msg__StatusString;

// Struct for a sequence of autonomy_msgs__msg__StatusString.
typedef struct autonomy_msgs__msg__StatusString__Sequence
{
  autonomy_msgs__msg__StatusString * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__StatusString__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_H_
