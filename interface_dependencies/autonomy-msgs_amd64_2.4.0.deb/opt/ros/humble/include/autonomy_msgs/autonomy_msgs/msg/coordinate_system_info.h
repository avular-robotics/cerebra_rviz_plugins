// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_H_
#define AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_H_

#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.h"
#include "autonomy_msgs/msg/detail/coordinate_system_info__functions.h"
#include "autonomy_msgs/msg/detail/coordinate_system_info__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_H_
