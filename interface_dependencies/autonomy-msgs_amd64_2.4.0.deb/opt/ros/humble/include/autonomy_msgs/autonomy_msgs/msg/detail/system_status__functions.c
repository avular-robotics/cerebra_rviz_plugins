// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/system_status__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `behavior_status`
// Member `position_accuracy_status`
// Member `mode_of_operation`
#include "rosidl_runtime_c/string_functions.h"

bool
autonomy_msgs__msg__SystemStatus__init(autonomy_msgs__msg__SystemStatus * msg)
{
  if (!msg) {
    return false;
  }
  // is_operational
  msg->is_operational = false;
  // behavior_status
  if (!rosidl_runtime_c__String__init(&msg->behavior_status)) {
    autonomy_msgs__msg__SystemStatus__fini(msg);
    return false;
  }
  {
    bool success = rosidl_runtime_c__String__assign(&msg->behavior_status, "No information yet.");
    if (!success) {
      goto abort_init_0;
    }
  }
  // position_accuracy_status
  if (!rosidl_runtime_c__String__init(&msg->position_accuracy_status)) {
    autonomy_msgs__msg__SystemStatus__fini(msg);
    return false;
  }
  {
    bool success = rosidl_runtime_c__String__assign(&msg->position_accuracy_status, "unknown");
    if (!success) {
      goto abort_init_1;
    }
  }
  // scheduling_enabled
  msg->scheduling_enabled = false;
  // mode_of_operation
  if (!rosidl_runtime_c__String__init(&msg->mode_of_operation)) {
    autonomy_msgs__msg__SystemStatus__fini(msg);
    return false;
  }
  {
    bool success = rosidl_runtime_c__String__assign(&msg->mode_of_operation, "default");
    if (!success) {
      goto abort_init_2;
    }
  }
  return true;
abort_init_2:
  rosidl_runtime_c__String__fini(&msg->position_accuracy_status);
abort_init_1:
  rosidl_runtime_c__String__fini(&msg->behavior_status);
abort_init_0:
  return false;
}

void
autonomy_msgs__msg__SystemStatus__fini(autonomy_msgs__msg__SystemStatus * msg)
{
  if (!msg) {
    return;
  }
  // is_operational
  // behavior_status
  rosidl_runtime_c__String__fini(&msg->behavior_status);
  // position_accuracy_status
  rosidl_runtime_c__String__fini(&msg->position_accuracy_status);
  // scheduling_enabled
  // mode_of_operation
  rosidl_runtime_c__String__fini(&msg->mode_of_operation);
}

bool
autonomy_msgs__msg__SystemStatus__are_equal(const autonomy_msgs__msg__SystemStatus * lhs, const autonomy_msgs__msg__SystemStatus * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // is_operational
  if (lhs->is_operational != rhs->is_operational) {
    return false;
  }
  // behavior_status
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->behavior_status), &(rhs->behavior_status)))
  {
    return false;
  }
  // position_accuracy_status
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->position_accuracy_status), &(rhs->position_accuracy_status)))
  {
    return false;
  }
  // scheduling_enabled
  if (lhs->scheduling_enabled != rhs->scheduling_enabled) {
    return false;
  }
  // mode_of_operation
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->mode_of_operation), &(rhs->mode_of_operation)))
  {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__SystemStatus__copy(
  const autonomy_msgs__msg__SystemStatus * input,
  autonomy_msgs__msg__SystemStatus * output)
{
  if (!input || !output) {
    return false;
  }
  // is_operational
  output->is_operational = input->is_operational;
  // behavior_status
  if (!rosidl_runtime_c__String__copy(
      &(input->behavior_status), &(output->behavior_status)))
  {
    return false;
  }
  // position_accuracy_status
  if (!rosidl_runtime_c__String__copy(
      &(input->position_accuracy_status), &(output->position_accuracy_status)))
  {
    return false;
  }
  // scheduling_enabled
  output->scheduling_enabled = input->scheduling_enabled;
  // mode_of_operation
  if (!rosidl_runtime_c__String__copy(
      &(input->mode_of_operation), &(output->mode_of_operation)))
  {
    return false;
  }
  return true;
}

autonomy_msgs__msg__SystemStatus *
autonomy_msgs__msg__SystemStatus__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__SystemStatus * msg = (autonomy_msgs__msg__SystemStatus *)allocator.allocate(sizeof(autonomy_msgs__msg__SystemStatus), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__SystemStatus));
  bool success = autonomy_msgs__msg__SystemStatus__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__SystemStatus__destroy(autonomy_msgs__msg__SystemStatus * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__SystemStatus__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__SystemStatus__Sequence__init(autonomy_msgs__msg__SystemStatus__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__SystemStatus * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__SystemStatus *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__SystemStatus), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__SystemStatus__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__SystemStatus__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__SystemStatus__Sequence__fini(autonomy_msgs__msg__SystemStatus__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__SystemStatus__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__SystemStatus__Sequence *
autonomy_msgs__msg__SystemStatus__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__SystemStatus__Sequence * array = (autonomy_msgs__msg__SystemStatus__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__SystemStatus__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__SystemStatus__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__SystemStatus__Sequence__destroy(autonomy_msgs__msg__SystemStatus__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__SystemStatus__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__SystemStatus__Sequence__are_equal(const autonomy_msgs__msg__SystemStatus__Sequence * lhs, const autonomy_msgs__msg__SystemStatus__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__SystemStatus__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__SystemStatus__Sequence__copy(
  const autonomy_msgs__msg__SystemStatus__Sequence * input,
  autonomy_msgs__msg__SystemStatus__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__SystemStatus);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__SystemStatus * data =
      (autonomy_msgs__msg__SystemStatus *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__SystemStatus__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__SystemStatus__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__SystemStatus__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
