// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__POLYGON_HPP_
#define AUTONOMY_MSGS__MSG__POLYGON_HPP_

#include "autonomy_msgs/msg/detail/polygon__struct.hpp"
#include "autonomy_msgs/msg/detail/polygon__builder.hpp"
#include "autonomy_msgs/msg/detail/polygon__traits.hpp"
#include "autonomy_msgs/msg/detail/polygon__type_support.hpp"

#endif  // AUTONOMY_MSGS__MSG__POLYGON_HPP_
