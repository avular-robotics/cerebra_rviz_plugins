// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/PoseWithTwist.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__POSE_WITH_TWIST_H_
#define AUTONOMY_MSGS__MSG__POSE_WITH_TWIST_H_

#include "autonomy_msgs/msg/detail/pose_with_twist__struct.h"
#include "autonomy_msgs/msg/detail/pose_with_twist__functions.h"
#include "autonomy_msgs/msg/detail/pose_with_twist__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__POSE_WITH_TWIST_H_
