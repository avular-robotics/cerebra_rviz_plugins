// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/GridMap2D.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/grid_map2_d__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `uuid`
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `map`
#include "nav_msgs/msg/detail/occupancy_grid__functions.h"

bool
autonomy_msgs__msg__GridMap2D__init(autonomy_msgs__msg__GridMap2D * msg)
{
  if (!msg) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__init(&msg->uuid)) {
    autonomy_msgs__msg__GridMap2D__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    autonomy_msgs__msg__GridMap2D__fini(msg);
    return false;
  }
  // map
  if (!nav_msgs__msg__OccupancyGrid__init(&msg->map)) {
    autonomy_msgs__msg__GridMap2D__fini(msg);
    return false;
  }
  return true;
}

void
autonomy_msgs__msg__GridMap2D__fini(autonomy_msgs__msg__GridMap2D * msg)
{
  if (!msg) {
    return;
  }
  // uuid
  rosidl_runtime_c__String__fini(&msg->uuid);
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // map
  nav_msgs__msg__OccupancyGrid__fini(&msg->map);
}

bool
autonomy_msgs__msg__GridMap2D__are_equal(const autonomy_msgs__msg__GridMap2D * lhs, const autonomy_msgs__msg__GridMap2D * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->uuid), &(rhs->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // map
  if (!nav_msgs__msg__OccupancyGrid__are_equal(
      &(lhs->map), &(rhs->map)))
  {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__GridMap2D__copy(
  const autonomy_msgs__msg__GridMap2D * input,
  autonomy_msgs__msg__GridMap2D * output)
{
  if (!input || !output) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__copy(
      &(input->uuid), &(output->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // map
  if (!nav_msgs__msg__OccupancyGrid__copy(
      &(input->map), &(output->map)))
  {
    return false;
  }
  return true;
}

autonomy_msgs__msg__GridMap2D *
autonomy_msgs__msg__GridMap2D__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__GridMap2D * msg = (autonomy_msgs__msg__GridMap2D *)allocator.allocate(sizeof(autonomy_msgs__msg__GridMap2D), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__GridMap2D));
  bool success = autonomy_msgs__msg__GridMap2D__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__GridMap2D__destroy(autonomy_msgs__msg__GridMap2D * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__GridMap2D__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__GridMap2D__Sequence__init(autonomy_msgs__msg__GridMap2D__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__GridMap2D * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__GridMap2D *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__GridMap2D), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__GridMap2D__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__GridMap2D__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__GridMap2D__Sequence__fini(autonomy_msgs__msg__GridMap2D__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__GridMap2D__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__GridMap2D__Sequence *
autonomy_msgs__msg__GridMap2D__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__GridMap2D__Sequence * array = (autonomy_msgs__msg__GridMap2D__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__GridMap2D__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__GridMap2D__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__GridMap2D__Sequence__destroy(autonomy_msgs__msg__GridMap2D__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__GridMap2D__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__GridMap2D__Sequence__are_equal(const autonomy_msgs__msg__GridMap2D__Sequence * lhs, const autonomy_msgs__msg__GridMap2D__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__GridMap2D__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__GridMap2D__Sequence__copy(
  const autonomy_msgs__msg__GridMap2D__Sequence * input,
  autonomy_msgs__msg__GridMap2D__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__GridMap2D);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__GridMap2D * data =
      (autonomy_msgs__msg__GridMap2D *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__GridMap2D__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__GridMap2D__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__GridMap2D__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
