// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__GET_STATE_H_
#define AUTONOMY_MSGS__SRV__GET_STATE_H_

#include "autonomy_msgs/srv/detail/get_state__struct.h"
#include "autonomy_msgs/srv/detail/get_state__functions.h"
#include "autonomy_msgs/srv/detail/get_state__type_support.h"

#endif  // AUTONOMY_MSGS__SRV__GET_STATE_H_
