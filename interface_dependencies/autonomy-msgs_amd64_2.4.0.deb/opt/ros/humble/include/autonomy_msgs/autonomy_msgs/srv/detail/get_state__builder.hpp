// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__BUILDER_HPP_
#define AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/srv/detail/get_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::srv::GetState_Request>()
{
  return ::autonomy_msgs::srv::GetState_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace autonomy_msgs


namespace autonomy_msgs
{

namespace srv
{

namespace builder
{

class Init_GetState_Response_message
{
public:
  explicit Init_GetState_Response_message(::autonomy_msgs::srv::GetState_Response & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::srv::GetState_Response message(::autonomy_msgs::srv::GetState_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::srv::GetState_Response msg_;
};

class Init_GetState_Response_success
{
public:
  explicit Init_GetState_Response_success(::autonomy_msgs::srv::GetState_Response & msg)
  : msg_(msg)
  {}
  Init_GetState_Response_message success(::autonomy_msgs::srv::GetState_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_GetState_Response_message(msg_);
  }

private:
  ::autonomy_msgs::srv::GetState_Response msg_;
};

class Init_GetState_Response_state
{
public:
  Init_GetState_Response_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetState_Response_success state(::autonomy_msgs::srv::GetState_Response::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_GetState_Response_success(msg_);
  }

private:
  ::autonomy_msgs::srv::GetState_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::srv::GetState_Response>()
{
  return autonomy_msgs::srv::builder::Init_GetState_Response_state();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__BUILDER_HPP_
