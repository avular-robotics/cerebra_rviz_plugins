// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:srv/SetState.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__STRUCT_H_
#define AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'state'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetState in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__SetState_Request
{
  rosidl_runtime_c__String state;
} autonomy_msgs__srv__SetState_Request;

// Struct for a sequence of autonomy_msgs__srv__SetState_Request.
typedef struct autonomy_msgs__srv__SetState_Request__Sequence
{
  autonomy_msgs__srv__SetState_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__SetState_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
// already included above
// #include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetState in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__SetState_Response
{
  bool success;
  rosidl_runtime_c__String message;
} autonomy_msgs__srv__SetState_Response;

// Struct for a sequence of autonomy_msgs__srv__SetState_Response.
typedef struct autonomy_msgs__srv__SetState_Response__Sequence
{
  autonomy_msgs__srv__SetState_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__SetState_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__STRUCT_H_
