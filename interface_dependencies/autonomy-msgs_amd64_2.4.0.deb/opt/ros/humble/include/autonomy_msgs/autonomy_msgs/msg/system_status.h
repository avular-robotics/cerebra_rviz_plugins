// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__SYSTEM_STATUS_H_
#define AUTONOMY_MSGS__MSG__SYSTEM_STATUS_H_

#include "autonomy_msgs/msg/detail/system_status__struct.h"
#include "autonomy_msgs/msg/detail/system_status__functions.h"
#include "autonomy_msgs/msg/detail/system_status__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__SYSTEM_STATUS_H_
