// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_HPP_
#define AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_HPP_

#include "autonomy_msgs/srv/detail/set_coordinate_system__struct.hpp"
#include "autonomy_msgs/srv/detail/set_coordinate_system__builder.hpp"
#include "autonomy_msgs/srv/detail/set_coordinate_system__traits.hpp"
#include "autonomy_msgs/srv/detail/set_coordinate_system__type_support.hpp"

#endif  // AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_HPP_
