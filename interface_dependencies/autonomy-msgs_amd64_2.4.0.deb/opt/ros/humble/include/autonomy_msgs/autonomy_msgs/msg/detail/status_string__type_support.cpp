// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "autonomy_msgs/msg/detail/status_string__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace autonomy_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void StatusString_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) autonomy_msgs::msg::StatusString(_init);
}

void StatusString_fini_function(void * message_memory)
{
  auto typed_message = static_cast<autonomy_msgs::msg::StatusString *>(message_memory);
  typed_message->~StatusString();
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember StatusString_message_member_array[1] = {
  {
    "status",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs::msg::StatusString, status),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers StatusString_message_members = {
  "autonomy_msgs::msg",  // message namespace
  "StatusString",  // message name
  1,  // number of fields
  sizeof(autonomy_msgs::msg::StatusString),
  StatusString_message_member_array,  // message members
  StatusString_init_function,  // function to initialize message memory (memory has to be allocated)
  StatusString_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t StatusString_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &StatusString_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace autonomy_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<autonomy_msgs::msg::StatusString>()
{
  return &::autonomy_msgs::msg::rosidl_typesupport_introspection_cpp::StatusString_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, autonomy_msgs, msg, StatusString)() {
  return &::autonomy_msgs::msg::rosidl_typesupport_introspection_cpp::StatusString_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
