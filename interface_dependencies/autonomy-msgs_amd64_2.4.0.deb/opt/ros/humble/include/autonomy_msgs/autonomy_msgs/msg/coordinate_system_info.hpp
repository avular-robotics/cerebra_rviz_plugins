// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_HPP_
#define AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_HPP_

#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.hpp"
#include "autonomy_msgs/msg/detail/coordinate_system_info__builder.hpp"
#include "autonomy_msgs/msg/detail/coordinate_system_info__traits.hpp"
#include "autonomy_msgs/msg/detail/coordinate_system_info__type_support.hpp"

#endif  // AUTONOMY_MSGS__MSG__COORDINATE_SYSTEM_INFO_HPP_
