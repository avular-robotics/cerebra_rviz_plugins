// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'LOCAL_RELATIVE'.
enum
{
  autonomy_msgs__msg__CoordinateSystemInfo__LOCAL_RELATIVE = 0
};

/// Constant 'LOCAL_TANGENT_PLANE'.
enum
{
  autonomy_msgs__msg__CoordinateSystemInfo__LOCAL_TANGENT_PLANE = 1
};

/// Constant 'UTM'.
enum
{
  autonomy_msgs__msg__CoordinateSystemInfo__UTM = 2
};

/// Constant 'UNKNOWN'.
enum
{
  autonomy_msgs__msg__CoordinateSystemInfo__UNKNOWN = 3
};

// Include directives for member types
// Member 'map_name'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/CoordinateSystemInfo in the package autonomy_msgs.
typedef struct autonomy_msgs__msg__CoordinateSystemInfo
{
  /// Type of coordinate system used, default value is UNKNOWN
  uint8_t type;
  /// Local relative only
  rosidl_runtime_c__String map_name;
  /// Local tangent plane only
  double latitude;
  double longitude;
  double altitude;
  /// UTM only
  /// Zone can be 0 to 60 (-1 is default/unknown)
  int8_t zone;
  bool north;
  double x_offset;
  double y_offset;
  double z_offset;
} autonomy_msgs__msg__CoordinateSystemInfo;

// Struct for a sequence of autonomy_msgs__msg__CoordinateSystemInfo.
typedef struct autonomy_msgs__msg__CoordinateSystemInfo__Sequence
{
  autonomy_msgs__msg__CoordinateSystemInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__CoordinateSystemInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__STRUCT_H_
