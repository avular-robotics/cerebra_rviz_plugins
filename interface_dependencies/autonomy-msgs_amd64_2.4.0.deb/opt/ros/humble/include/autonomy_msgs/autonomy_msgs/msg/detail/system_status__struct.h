// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN'.
/**
  * This status indicates whether the robot has accurate positioning information that would allow it to autonomously navigate.
  * The position_accuracy_status is either:
  * Indicates that no position estimate is received yet
 */
static const char * const autonomy_msgs__msg__SystemStatus__UNKNOWN = "unknown";

/// Constant 'INACCURATE_POSITION'.
/**
  * indicates that a position is estimated but it is not accurate yet
 */
static const char * const autonomy_msgs__msg__SystemStatus__INACCURATE_POSITION = "inaccurate_position";

/// Constant 'INACCURATE_HEADING'.
/**
  * indicates that an accurate position estimate is available, but no accurate heading
 */
static const char * const autonomy_msgs__msg__SystemStatus__INACCURATE_HEADING = "inaccurate_heading";

/// Constant 'ACCURATE'.
/**
  * indicates that an accurate position and orientation are available
 */
static const char * const autonomy_msgs__msg__SystemStatus__ACCURATE = "accurate";

/// Constant 'DEFAULT'.
/**
  * The current mode the Autopilot is operating in. The constants are just some of the possible modes of operation;
  * see knowledge_base_msgs/msg/ModeOfOperation for more info
 */
static const char * const autonomy_msgs__msg__SystemStatus__DEFAULT = "default";

/// Constant 'MAPPING'.
static const char * const autonomy_msgs__msg__SystemStatus__MAPPING = "mapping";

/// Constant 'MULTIMAP'.
static const char * const autonomy_msgs__msg__SystemStatus__MULTIMAP = "multimap";

// Include directives for member types
// Member 'behavior_status'
// Member 'position_accuracy_status'
// Member 'mode_of_operation'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/SystemStatus in the package autonomy_msgs.
/**
  * This message describes the statuses that will be reported by the user interface node.
  * In case any of these are not the desired value, please refer to the autopilot user interface.
 */
typedef struct autonomy_msgs__msg__SystemStatus
{
  /// This indicates whether the robot is fully booted and ready for user operations.
  bool is_operational;
  /// This status reflects the current behavior status of the robot
  rosidl_runtime_c__String behavior_status;
  rosidl_runtime_c__String position_accuracy_status;
  /// This boolean indicates if the scheduler is running on the robot. The scheduler when enabled will start scheduled jobs
  /// at the specified moments in time
  bool scheduling_enabled;
  rosidl_runtime_c__String mode_of_operation;
} autonomy_msgs__msg__SystemStatus;

// Struct for a sequence of autonomy_msgs__msg__SystemStatus.
typedef struct autonomy_msgs__msg__SystemStatus__Sequence
{
  autonomy_msgs__msg__SystemStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__SystemStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_H_
