// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/Path.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__PATH__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__PATH__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'uuid'
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'info'
#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.h"
// Member 'poses'
#include "autonomy_msgs/msg/detail/pose_with_twist__struct.h"

/// Struct defined in msg/Path in the package autonomy_msgs.
/**
  * Unique generated id
 */
typedef struct autonomy_msgs__msg__Path
{
  rosidl_runtime_c__String uuid;
  /// Human readable name
  rosidl_runtime_c__String name;
  std_msgs__msg__Header header;
  autonomy_msgs__msg__CoordinateSystemInfo info;
  autonomy_msgs__msg__PoseWithTwist__Sequence poses;
} autonomy_msgs__msg__Path;

// Struct for a sequence of autonomy_msgs__msg__Path.
typedef struct autonomy_msgs__msg__Path__Sequence
{
  autonomy_msgs__msg__Path * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__Path__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__PATH__STRUCT_H_
