// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autonomy_msgs:msg/GridMap2D.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'map'
#include "nav_msgs/msg/detail/occupancy_grid__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__msg__GridMap2D __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__msg__GridMap2D __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct GridMap2D_
{
  using Type = GridMap2D_<ContainerAllocator>;

  explicit GridMap2D_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : map(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->uuid = "";
      this->name = "";
    }
  }

  explicit GridMap2D_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : uuid(_alloc),
    name(_alloc),
    map(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->uuid = "";
      this->name = "";
    }
  }

  // field types and members
  using _uuid_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _uuid_type uuid;
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _map_type =
    nav_msgs::msg::OccupancyGrid_<ContainerAllocator>;
  _map_type map;

  // setters for named parameter idiom
  Type & set__uuid(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->uuid = _arg;
    return *this;
  }
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__map(
    const nav_msgs::msg::OccupancyGrid_<ContainerAllocator> & _arg)
  {
    this->map = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autonomy_msgs::msg::GridMap2D_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::msg::GridMap2D_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::GridMap2D_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::GridMap2D_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__msg__GridMap2D
    std::shared_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__msg__GridMap2D
    std::shared_ptr<autonomy_msgs::msg::GridMap2D_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const GridMap2D_ & other) const
  {
    if (this->uuid != other.uuid) {
      return false;
    }
    if (this->name != other.name) {
      return false;
    }
    if (this->map != other.map) {
      return false;
    }
    return true;
  }
  bool operator!=(const GridMap2D_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct GridMap2D_

// alias to use template instance with default allocator
using GridMap2D =
  autonomy_msgs::msg::GridMap2D_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__STRUCT_HPP_
