// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/Path.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__PATH_H_
#define AUTONOMY_MSGS__MSG__PATH_H_

#include "autonomy_msgs/msg/detail/path__struct.h"
#include "autonomy_msgs/msg/detail/path__functions.h"
#include "autonomy_msgs/msg/detail/path__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__PATH_H_
