// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__FUNCTIONS_H_
#define AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "autonomy_msgs/msg/rosidl_generator_c__visibility_control.h"

#include "autonomy_msgs/msg/detail/status_string__struct.h"

/// Initialize msg/StatusString message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * autonomy_msgs__msg__StatusString
 * )) before or use
 * autonomy_msgs__msg__StatusString__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__init(autonomy_msgs__msg__StatusString * msg);

/// Finalize msg/StatusString message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
void
autonomy_msgs__msg__StatusString__fini(autonomy_msgs__msg__StatusString * msg);

/// Create msg/StatusString message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * autonomy_msgs__msg__StatusString__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
autonomy_msgs__msg__StatusString *
autonomy_msgs__msg__StatusString__create();

/// Destroy msg/StatusString message.
/**
 * It calls
 * autonomy_msgs__msg__StatusString__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
void
autonomy_msgs__msg__StatusString__destroy(autonomy_msgs__msg__StatusString * msg);

/// Check for msg/StatusString message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__are_equal(const autonomy_msgs__msg__StatusString * lhs, const autonomy_msgs__msg__StatusString * rhs);

/// Copy a msg/StatusString message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__copy(
  const autonomy_msgs__msg__StatusString * input,
  autonomy_msgs__msg__StatusString * output);

/// Initialize array of msg/StatusString messages.
/**
 * It allocates the memory for the number of elements and calls
 * autonomy_msgs__msg__StatusString__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__Sequence__init(autonomy_msgs__msg__StatusString__Sequence * array, size_t size);

/// Finalize array of msg/StatusString messages.
/**
 * It calls
 * autonomy_msgs__msg__StatusString__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
void
autonomy_msgs__msg__StatusString__Sequence__fini(autonomy_msgs__msg__StatusString__Sequence * array);

/// Create array of msg/StatusString messages.
/**
 * It allocates the memory for the array and calls
 * autonomy_msgs__msg__StatusString__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
autonomy_msgs__msg__StatusString__Sequence *
autonomy_msgs__msg__StatusString__Sequence__create(size_t size);

/// Destroy array of msg/StatusString messages.
/**
 * It calls
 * autonomy_msgs__msg__StatusString__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
void
autonomy_msgs__msg__StatusString__Sequence__destroy(autonomy_msgs__msg__StatusString__Sequence * array);

/// Check for msg/StatusString message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__Sequence__are_equal(const autonomy_msgs__msg__StatusString__Sequence * lhs, const autonomy_msgs__msg__StatusString__Sequence * rhs);

/// Copy an array of msg/StatusString messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
bool
autonomy_msgs__msg__StatusString__Sequence__copy(
  const autonomy_msgs__msg__StatusString__Sequence * input,
  autonomy_msgs__msg__StatusString__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__FUNCTIONS_H_
