// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autonomy_msgs:msg/CoordinateSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__TRAITS_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace autonomy_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const CoordinateSystemInfo & msg,
  std::ostream & out)
{
  out << "{";
  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << ", ";
  }

  // member: map_name
  {
    out << "map_name: ";
    rosidl_generator_traits::value_to_yaml(msg.map_name, out);
    out << ", ";
  }

  // member: latitude
  {
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << ", ";
  }

  // member: longitude
  {
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << ", ";
  }

  // member: altitude
  {
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << ", ";
  }

  // member: zone
  {
    out << "zone: ";
    rosidl_generator_traits::value_to_yaml(msg.zone, out);
    out << ", ";
  }

  // member: north
  {
    out << "north: ";
    rosidl_generator_traits::value_to_yaml(msg.north, out);
    out << ", ";
  }

  // member: x_offset
  {
    out << "x_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.x_offset, out);
    out << ", ";
  }

  // member: y_offset
  {
    out << "y_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.y_offset, out);
    out << ", ";
  }

  // member: z_offset
  {
    out << "z_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.z_offset, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const CoordinateSystemInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }

  // member: map_name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "map_name: ";
    rosidl_generator_traits::value_to_yaml(msg.map_name, out);
    out << "\n";
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    rosidl_generator_traits::value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    rosidl_generator_traits::value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: altitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "altitude: ";
    rosidl_generator_traits::value_to_yaml(msg.altitude, out);
    out << "\n";
  }

  // member: zone
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "zone: ";
    rosidl_generator_traits::value_to_yaml(msg.zone, out);
    out << "\n";
  }

  // member: north
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "north: ";
    rosidl_generator_traits::value_to_yaml(msg.north, out);
    out << "\n";
  }

  // member: x_offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "x_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.x_offset, out);
    out << "\n";
  }

  // member: y_offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "y_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.y_offset, out);
    out << "\n";
  }

  // member: z_offset
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "z_offset: ";
    rosidl_generator_traits::value_to_yaml(msg.z_offset, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const CoordinateSystemInfo & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::msg::CoordinateSystemInfo & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::msg::CoordinateSystemInfo & msg)
{
  return autonomy_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::msg::CoordinateSystemInfo>()
{
  return "autonomy_msgs::msg::CoordinateSystemInfo";
}

template<>
inline const char * name<autonomy_msgs::msg::CoordinateSystemInfo>()
{
  return "autonomy_msgs/msg/CoordinateSystemInfo";
}

template<>
struct has_fixed_size<autonomy_msgs::msg::CoordinateSystemInfo>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::msg::CoordinateSystemInfo>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::msg::CoordinateSystemInfo>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AUTONOMY_MSGS__MSG__DETAIL__COORDINATE_SYSTEM_INFO__TRAITS_HPP_
