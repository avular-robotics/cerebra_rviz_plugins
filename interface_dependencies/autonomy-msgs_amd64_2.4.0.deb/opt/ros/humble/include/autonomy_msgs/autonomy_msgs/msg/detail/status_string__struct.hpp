// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__msg__StatusString __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__msg__StatusString __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct StatusString_
{
  using Type = StatusString_<ContainerAllocator>;

  explicit StatusString_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = "";
    }
  }

  explicit StatusString_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : status(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->status = "";
    }
  }

  // field types and members
  using _status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _status_type status;

  // setters for named parameter idiom
  Type & set__status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->status = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    autonomy_msgs::msg::StatusString_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::msg::StatusString_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::StatusString_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::StatusString_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__msg__StatusString
    std::shared_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__msg__StatusString
    std::shared_ptr<autonomy_msgs::msg::StatusString_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const StatusString_ & other) const
  {
    if (this->status != other.status) {
      return false;
    }
    return true;
  }
  bool operator!=(const StatusString_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct StatusString_

// alias to use template instance with default allocator
using StatusString =
  autonomy_msgs::msg::StatusString_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__STRUCT_HPP_
