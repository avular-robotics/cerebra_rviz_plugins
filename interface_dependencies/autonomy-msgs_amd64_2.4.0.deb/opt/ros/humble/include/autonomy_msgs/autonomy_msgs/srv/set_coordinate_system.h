// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:srv/SetCoordinateSystem.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_H_
#define AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_H_

#include "autonomy_msgs/srv/detail/set_coordinate_system__struct.h"
#include "autonomy_msgs/srv/detail/set_coordinate_system__functions.h"
#include "autonomy_msgs/srv/detail/set_coordinate_system__type_support.h"

#endif  // AUTONOMY_MSGS__SRV__SET_COORDINATE_SYSTEM_H_
