// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TRAITS_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autonomy_msgs/msg/detail/system_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace autonomy_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const SystemStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: is_operational
  {
    out << "is_operational: ";
    rosidl_generator_traits::value_to_yaml(msg.is_operational, out);
    out << ", ";
  }

  // member: behavior_status
  {
    out << "behavior_status: ";
    rosidl_generator_traits::value_to_yaml(msg.behavior_status, out);
    out << ", ";
  }

  // member: position_accuracy_status
  {
    out << "position_accuracy_status: ";
    rosidl_generator_traits::value_to_yaml(msg.position_accuracy_status, out);
    out << ", ";
  }

  // member: scheduling_enabled
  {
    out << "scheduling_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.scheduling_enabled, out);
    out << ", ";
  }

  // member: mode_of_operation
  {
    out << "mode_of_operation: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_of_operation, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SystemStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: is_operational
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_operational: ";
    rosidl_generator_traits::value_to_yaml(msg.is_operational, out);
    out << "\n";
  }

  // member: behavior_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "behavior_status: ";
    rosidl_generator_traits::value_to_yaml(msg.behavior_status, out);
    out << "\n";
  }

  // member: position_accuracy_status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_accuracy_status: ";
    rosidl_generator_traits::value_to_yaml(msg.position_accuracy_status, out);
    out << "\n";
  }

  // member: scheduling_enabled
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "scheduling_enabled: ";
    rosidl_generator_traits::value_to_yaml(msg.scheduling_enabled, out);
    out << "\n";
  }

  // member: mode_of_operation
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mode_of_operation: ";
    rosidl_generator_traits::value_to_yaml(msg.mode_of_operation, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SystemStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::msg::SystemStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::msg::SystemStatus & msg)
{
  return autonomy_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::msg::SystemStatus>()
{
  return "autonomy_msgs::msg::SystemStatus";
}

template<>
inline const char * name<autonomy_msgs::msg::SystemStatus>()
{
  return "autonomy_msgs/msg/SystemStatus";
}

template<>
struct has_fixed_size<autonomy_msgs::msg::SystemStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::msg::SystemStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::msg::SystemStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__TRAITS_HPP_
