// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_
#define AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/GetState in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__GetState_Request
{
  uint8_t structure_needs_at_least_one_member;
} autonomy_msgs__srv__GetState_Request;

// Struct for a sequence of autonomy_msgs__srv__GetState_Request.
typedef struct autonomy_msgs__srv__GetState_Request__Sequence
{
  autonomy_msgs__srv__GetState_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__GetState_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'state'
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/GetState in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__GetState_Response
{
  rosidl_runtime_c__String state;
  bool success;
  rosidl_runtime_c__String message;
} autonomy_msgs__srv__GetState_Response;

// Struct for a sequence of autonomy_msgs__srv__GetState_Response.
typedef struct autonomy_msgs__srv__GetState_Response__Sequence
{
  autonomy_msgs__srv__GetState_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__GetState_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_
