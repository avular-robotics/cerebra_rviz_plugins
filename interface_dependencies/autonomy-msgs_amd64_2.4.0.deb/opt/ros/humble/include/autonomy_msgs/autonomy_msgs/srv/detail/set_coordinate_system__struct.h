// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:srv/SetCoordinateSystem.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_H_
#define AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'info'
#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.h"

/// Struct defined in srv/SetCoordinateSystem in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__SetCoordinateSystem_Request
{
  /// Coordinate system info to be used
  autonomy_msgs__msg__CoordinateSystemInfo info;
} autonomy_msgs__srv__SetCoordinateSystem_Request;

// Struct for a sequence of autonomy_msgs__srv__SetCoordinateSystem_Request.
typedef struct autonomy_msgs__srv__SetCoordinateSystem_Request__Sequence
{
  autonomy_msgs__srv__SetCoordinateSystem_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__SetCoordinateSystem_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SetCoordinateSystem in the package autonomy_msgs.
typedef struct autonomy_msgs__srv__SetCoordinateSystem_Response
{
  bool success;
  /// Confirmation or error message
  rosidl_runtime_c__String message;
} autonomy_msgs__srv__SetCoordinateSystem_Response;

// Struct for a sequence of autonomy_msgs__srv__SetCoordinateSystem_Response.
typedef struct autonomy_msgs__srv__SetCoordinateSystem_Response__Sequence
{
  autonomy_msgs__srv__SetCoordinateSystem_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__srv__SetCoordinateSystem_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__STRUCT_H_
