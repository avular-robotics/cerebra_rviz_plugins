// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from autonomy_msgs:msg/Polygon.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__POLYGON__STRUCT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__POLYGON__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'uuid'
// Member 'name'
#include "rosidl_runtime_c/string.h"
// Member 'info'
#include "autonomy_msgs/msg/detail/coordinate_system_info__struct.h"
// Member 'points'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in msg/Polygon in the package autonomy_msgs.
/**
  * Unique generated id
 */
typedef struct autonomy_msgs__msg__Polygon
{
  rosidl_runtime_c__String uuid;
  /// Human readable name
  rosidl_runtime_c__String name;
  /// Coordinate system used for points
  autonomy_msgs__msg__CoordinateSystemInfo info;
  /// Points in polygon
  /// Note, while these are 3d points, they should always be on the same plane.
  /// It will be up to the algorithm whether this is the xy plane, or something else.
  geometry_msgs__msg__Point__Sequence points;
  /// Whether it is a right sided polygon.
  /// If it is, if you define them clockwise, it will describe the area inside.
  bool right_sided;
} autonomy_msgs__msg__Polygon;

// Struct for a sequence of autonomy_msgs__msg__Polygon.
typedef struct autonomy_msgs__msg__Polygon__Sequence
{
  autonomy_msgs__msg__Polygon * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} autonomy_msgs__msg__Polygon__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__POLYGON__STRUCT_H_
