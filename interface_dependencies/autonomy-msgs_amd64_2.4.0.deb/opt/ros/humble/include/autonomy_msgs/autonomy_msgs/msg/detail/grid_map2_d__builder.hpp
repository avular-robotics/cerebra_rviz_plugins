// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/GridMap2D.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/grid_map2_d__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_GridMap2D_map
{
public:
  explicit Init_GridMap2D_map(::autonomy_msgs::msg::GridMap2D & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::GridMap2D map(::autonomy_msgs::msg::GridMap2D::_map_type arg)
  {
    msg_.map = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::GridMap2D msg_;
};

class Init_GridMap2D_name
{
public:
  explicit Init_GridMap2D_name(::autonomy_msgs::msg::GridMap2D & msg)
  : msg_(msg)
  {}
  Init_GridMap2D_map name(::autonomy_msgs::msg::GridMap2D::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_GridMap2D_map(msg_);
  }

private:
  ::autonomy_msgs::msg::GridMap2D msg_;
};

class Init_GridMap2D_uuid
{
public:
  Init_GridMap2D_uuid()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GridMap2D_name uuid(::autonomy_msgs::msg::GridMap2D::_uuid_type arg)
  {
    msg_.uuid = std::move(arg);
    return Init_GridMap2D_name(msg_);
  }

private:
  ::autonomy_msgs::msg::GridMap2D msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::GridMap2D>()
{
  return autonomy_msgs::msg::builder::Init_GridMap2D_uuid();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__BUILDER_HPP_
