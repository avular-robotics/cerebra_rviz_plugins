// generated from rosidl_typesupport_introspection_c/resource/idl__type_support.c.em
// with input from autonomy_msgs:msg/Polygon.idl
// generated code does not contain a copyright notice

#include <stddef.h>
#include "autonomy_msgs/msg/detail/polygon__rosidl_typesupport_introspection_c.h"
#include "autonomy_msgs/msg/rosidl_typesupport_introspection_c__visibility_control.h"
#include "rosidl_typesupport_introspection_c/field_types.h"
#include "rosidl_typesupport_introspection_c/identifier.h"
#include "rosidl_typesupport_introspection_c/message_introspection.h"
#include "autonomy_msgs/msg/detail/polygon__functions.h"
#include "autonomy_msgs/msg/detail/polygon__struct.h"


// Include directives for member types
// Member `uuid`
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `info`
#include "autonomy_msgs/msg/coordinate_system_info.h"
// Member `info`
#include "autonomy_msgs/msg/detail/coordinate_system_info__rosidl_typesupport_introspection_c.h"
// Member `points`
#include "geometry_msgs/msg/point.h"
// Member `points`
#include "geometry_msgs/msg/detail/point__rosidl_typesupport_introspection_c.h"

#ifdef __cplusplus
extern "C"
{
#endif

void autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_init_function(
  void * message_memory, enum rosidl_runtime_c__message_initialization _init)
{
  // TODO(karsten1987): initializers are not yet implemented for typesupport c
  // see https://github.com/ros2/ros2/issues/397
  (void) _init;
  autonomy_msgs__msg__Polygon__init(message_memory);
}

void autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_fini_function(void * message_memory)
{
  autonomy_msgs__msg__Polygon__fini(message_memory);
}

size_t autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__size_function__Polygon__points(
  const void * untyped_member)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return member->size;
}

const void * autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_const_function__Polygon__points(
  const void * untyped_member, size_t index)
{
  const geometry_msgs__msg__Point__Sequence * member =
    (const geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void * autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_function__Polygon__points(
  void * untyped_member, size_t index)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  return &member->data[index];
}

void autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__fetch_function__Polygon__points(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const geometry_msgs__msg__Point * item =
    ((const geometry_msgs__msg__Point *)
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_const_function__Polygon__points(untyped_member, index));
  geometry_msgs__msg__Point * value =
    (geometry_msgs__msg__Point *)(untyped_value);
  *value = *item;
}

void autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__assign_function__Polygon__points(
  void * untyped_member, size_t index, const void * untyped_value)
{
  geometry_msgs__msg__Point * item =
    ((geometry_msgs__msg__Point *)
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_function__Polygon__points(untyped_member, index));
  const geometry_msgs__msg__Point * value =
    (const geometry_msgs__msg__Point *)(untyped_value);
  *item = *value;
}

bool autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__resize_function__Polygon__points(
  void * untyped_member, size_t size)
{
  geometry_msgs__msg__Point__Sequence * member =
    (geometry_msgs__msg__Point__Sequence *)(untyped_member);
  geometry_msgs__msg__Point__Sequence__fini(member);
  return geometry_msgs__msg__Point__Sequence__init(member, size);
}

static rosidl_typesupport_introspection_c__MessageMember autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_member_array[5] = {
  {
    "uuid",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__Polygon, uuid),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "name",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__Polygon, name),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "info",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__Polygon, info),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  },
  {
    "points",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    NULL,  // members of sub message (initialized later)
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__Polygon, points),  // bytes offset in struct
    NULL,  // default value
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__size_function__Polygon__points,  // size() function pointer
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_const_function__Polygon__points,  // get_const(index) function pointer
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__get_function__Polygon__points,  // get(index) function pointer
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__fetch_function__Polygon__points,  // fetch(index, &value) function pointer
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__assign_function__Polygon__points,  // assign(index, value) function pointer
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__resize_function__Polygon__points  // resize(index) function pointer
  },
  {
    "right_sided",  // name
    rosidl_typesupport_introspection_c__ROS_TYPE_BOOLEAN,  // type
    0,  // upper bound of string
    NULL,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(autonomy_msgs__msg__Polygon, right_sided),  // bytes offset in struct
    NULL,  // default value
    NULL,  // size() function pointer
    NULL,  // get_const(index) function pointer
    NULL,  // get(index) function pointer
    NULL,  // fetch(index, &value) function pointer
    NULL,  // assign(index, value) function pointer
    NULL  // resize(index) function pointer
  }
};

static const rosidl_typesupport_introspection_c__MessageMembers autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_members = {
  "autonomy_msgs__msg",  // message namespace
  "Polygon",  // message name
  5,  // number of fields
  sizeof(autonomy_msgs__msg__Polygon),
  autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_member_array,  // message members
  autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_init_function,  // function to initialize message memory (memory has to be allocated)
  autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_fini_function  // function to terminate message instance (will not free memory)
};

// this is not const since it must be initialized on first access
// since C does not allow non-integral compile-time constants
static rosidl_message_type_support_t autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_type_support_handle = {
  0,
  &autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_members,
  get_message_typesupport_handle_function,
};

ROSIDL_TYPESUPPORT_INTROSPECTION_C_EXPORT_autonomy_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autonomy_msgs, msg, Polygon)() {
  autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_member_array[2].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, autonomy_msgs, msg, CoordinateSystemInfo)();
  autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_member_array[3].members_ =
    ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, geometry_msgs, msg, Point)();
  if (!autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_type_support_handle.typesupport_identifier) {
    autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_type_support_handle.typesupport_identifier =
      rosidl_typesupport_introspection_c__identifier;
  }
  return &autonomy_msgs__msg__Polygon__rosidl_typesupport_introspection_c__Polygon_message_type_support_handle;
}
#ifdef __cplusplus
}
#endif
