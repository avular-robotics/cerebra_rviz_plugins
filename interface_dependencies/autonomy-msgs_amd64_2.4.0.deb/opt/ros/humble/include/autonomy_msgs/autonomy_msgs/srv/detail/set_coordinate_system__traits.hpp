// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autonomy_msgs:srv/SetCoordinateSystem.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__TRAITS_HPP_
#define AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autonomy_msgs/srv/detail/set_coordinate_system__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'info'
#include "autonomy_msgs/msg/detail/coordinate_system_info__traits.hpp"

namespace autonomy_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetCoordinateSystem_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: info
  {
    out << "info: ";
    to_flow_style_yaml(msg.info, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetCoordinateSystem_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: info
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "info:\n";
    to_block_style_yaml(msg.info, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetCoordinateSystem_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::srv::SetCoordinateSystem_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::srv::SetCoordinateSystem_Request & msg)
{
  return autonomy_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::srv::SetCoordinateSystem_Request>()
{
  return "autonomy_msgs::srv::SetCoordinateSystem_Request";
}

template<>
inline const char * name<autonomy_msgs::srv::SetCoordinateSystem_Request>()
{
  return "autonomy_msgs/srv/SetCoordinateSystem_Request";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetCoordinateSystem_Request>
  : std::integral_constant<bool, has_fixed_size<autonomy_msgs::msg::CoordinateSystemInfo>::value> {};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetCoordinateSystem_Request>
  : std::integral_constant<bool, has_bounded_size<autonomy_msgs::msg::CoordinateSystemInfo>::value> {};

template<>
struct is_message<autonomy_msgs::srv::SetCoordinateSystem_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace autonomy_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetCoordinateSystem_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetCoordinateSystem_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetCoordinateSystem_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::srv::SetCoordinateSystem_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::srv::SetCoordinateSystem_Response & msg)
{
  return autonomy_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::srv::SetCoordinateSystem_Response>()
{
  return "autonomy_msgs::srv::SetCoordinateSystem_Response";
}

template<>
inline const char * name<autonomy_msgs::srv::SetCoordinateSystem_Response>()
{
  return "autonomy_msgs/srv/SetCoordinateSystem_Response";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetCoordinateSystem_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetCoordinateSystem_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::srv::SetCoordinateSystem_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<autonomy_msgs::srv::SetCoordinateSystem>()
{
  return "autonomy_msgs::srv::SetCoordinateSystem";
}

template<>
inline const char * name<autonomy_msgs::srv::SetCoordinateSystem>()
{
  return "autonomy_msgs/srv/SetCoordinateSystem";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetCoordinateSystem>
  : std::integral_constant<
    bool,
    has_fixed_size<autonomy_msgs::srv::SetCoordinateSystem_Request>::value &&
    has_fixed_size<autonomy_msgs::srv::SetCoordinateSystem_Response>::value
  >
{
};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetCoordinateSystem>
  : std::integral_constant<
    bool,
    has_bounded_size<autonomy_msgs::srv::SetCoordinateSystem_Request>::value &&
    has_bounded_size<autonomy_msgs::srv::SetCoordinateSystem_Response>::value
  >
{
};

template<>
struct is_service<autonomy_msgs::srv::SetCoordinateSystem>
  : std::true_type
{
};

template<>
struct is_service_request<autonomy_msgs::srv::SetCoordinateSystem_Request>
  : std::true_type
{
};

template<>
struct is_service_response<autonomy_msgs::srv::SetCoordinateSystem_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AUTONOMY_MSGS__SRV__DETAIL__SET_COORDINATE_SYSTEM__TRAITS_HPP_
