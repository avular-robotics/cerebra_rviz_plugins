// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from autonomy_msgs:msg/GridMap2D.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__TYPE_SUPPORT_H_
#define AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "autonomy_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_autonomy_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  autonomy_msgs,
  msg,
  GridMap2D
)();

#ifdef __cplusplus
}
#endif

#endif  // AUTONOMY_MSGS__MSG__DETAIL__GRID_MAP2_D__TYPE_SUPPORT_H_
