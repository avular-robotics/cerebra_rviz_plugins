// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/PoseWithTwist.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/pose_with_twist__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_PoseWithTwist_twist
{
public:
  explicit Init_PoseWithTwist_twist(::autonomy_msgs::msg::PoseWithTwist & msg)
  : msg_(msg)
  {}
  ::autonomy_msgs::msg::PoseWithTwist twist(::autonomy_msgs::msg::PoseWithTwist::_twist_type arg)
  {
    msg_.twist = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::PoseWithTwist msg_;
};

class Init_PoseWithTwist_pose
{
public:
  Init_PoseWithTwist_pose()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_PoseWithTwist_twist pose(::autonomy_msgs::msg::PoseWithTwist::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_PoseWithTwist_twist(msg_);
  }

private:
  ::autonomy_msgs::msg::PoseWithTwist msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::PoseWithTwist>()
{
  return autonomy_msgs::msg::builder::Init_PoseWithTwist_pose();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__POSE_WITH_TWIST__BUILDER_HPP_
