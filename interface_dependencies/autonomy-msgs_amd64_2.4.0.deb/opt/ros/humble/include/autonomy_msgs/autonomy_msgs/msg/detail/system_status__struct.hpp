// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from autonomy_msgs:msg/SystemStatus.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__autonomy_msgs__msg__SystemStatus __attribute__((deprecated))
#else
# define DEPRECATED__autonomy_msgs__msg__SystemStatus __declspec(deprecated)
#endif

namespace autonomy_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemStatus_
{
  using Type = SystemStatus_<ContainerAllocator>;

  explicit SystemStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->is_operational = false;
      this->behavior_status = "No information yet.";
      this->position_accuracy_status = "unknown";
      this->scheduling_enabled = false;
      this->mode_of_operation = "default";
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->is_operational = false;
      this->behavior_status = "";
      this->position_accuracy_status = "";
      this->scheduling_enabled = false;
      this->mode_of_operation = "";
    }
  }

  explicit SystemStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : behavior_status(_alloc),
    position_accuracy_status(_alloc),
    mode_of_operation(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->is_operational = false;
      this->behavior_status = "No information yet.";
      this->position_accuracy_status = "unknown";
      this->scheduling_enabled = false;
      this->mode_of_operation = "default";
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->is_operational = false;
      this->behavior_status = "";
      this->position_accuracy_status = "";
      this->scheduling_enabled = false;
      this->mode_of_operation = "";
    }
  }

  // field types and members
  using _is_operational_type =
    bool;
  _is_operational_type is_operational;
  using _behavior_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _behavior_status_type behavior_status;
  using _position_accuracy_status_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _position_accuracy_status_type position_accuracy_status;
  using _scheduling_enabled_type =
    bool;
  _scheduling_enabled_type scheduling_enabled;
  using _mode_of_operation_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _mode_of_operation_type mode_of_operation;

  // setters for named parameter idiom
  Type & set__is_operational(
    const bool & _arg)
  {
    this->is_operational = _arg;
    return *this;
  }
  Type & set__behavior_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->behavior_status = _arg;
    return *this;
  }
  Type & set__position_accuracy_status(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->position_accuracy_status = _arg;
    return *this;
  }
  Type & set__scheduling_enabled(
    const bool & _arg)
  {
    this->scheduling_enabled = _arg;
    return *this;
  }
  Type & set__mode_of_operation(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->mode_of_operation = _arg;
    return *this;
  }

  // constant declarations
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> UNKNOWN;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> INACCURATE_POSITION;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> INACCURATE_HEADING;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> ACCURATE;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> DEFAULT;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> MAPPING;
  static const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> MULTIMAP;

  // pointer types
  using RawPtr =
    autonomy_msgs::msg::SystemStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const autonomy_msgs::msg::SystemStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::SystemStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      autonomy_msgs::msg::SystemStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__autonomy_msgs__msg__SystemStatus
    std::shared_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__autonomy_msgs__msg__SystemStatus
    std::shared_ptr<autonomy_msgs::msg::SystemStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemStatus_ & other) const
  {
    if (this->is_operational != other.is_operational) {
      return false;
    }
    if (this->behavior_status != other.behavior_status) {
      return false;
    }
    if (this->position_accuracy_status != other.position_accuracy_status) {
      return false;
    }
    if (this->scheduling_enabled != other.scheduling_enabled) {
      return false;
    }
    if (this->mode_of_operation != other.mode_of_operation) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemStatus_

// alias to use template instance with default allocator
using SystemStatus =
  autonomy_msgs::msg::SystemStatus_<std::allocator<void>>;

// constant definitions
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::UNKNOWN = "unknown";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::INACCURATE_POSITION = "inaccurate_position";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::INACCURATE_HEADING = "inaccurate_heading";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::ACCURATE = "accurate";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::DEFAULT = "default";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::MAPPING = "mapping";
template<typename ContainerAllocator>
const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>
SystemStatus_<ContainerAllocator>::MULTIMAP = "multimap";

}  // namespace msg

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__SYSTEM_STATUS__STRUCT_HPP_
