// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from autonomy_msgs:msg/StatusString.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__BUILDER_HPP_
#define AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "autonomy_msgs/msg/detail/status_string__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace autonomy_msgs
{

namespace msg
{

namespace builder
{

class Init_StatusString_status
{
public:
  Init_StatusString_status()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::autonomy_msgs::msg::StatusString status(::autonomy_msgs::msg::StatusString::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::autonomy_msgs::msg::StatusString msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::autonomy_msgs::msg::StatusString>()
{
  return autonomy_msgs::msg::builder::Init_StatusString_status();
}

}  // namespace autonomy_msgs

#endif  // AUTONOMY_MSGS__MSG__DETAIL__STATUS_STRING__BUILDER_HPP_
