// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from autonomy_msgs:msg/Path.idl
// generated code does not contain a copyright notice
#include "autonomy_msgs/msg/detail/path__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `uuid`
// Member `name`
#include "rosidl_runtime_c/string_functions.h"
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `info`
#include "autonomy_msgs/msg/detail/coordinate_system_info__functions.h"
// Member `poses`
#include "autonomy_msgs/msg/detail/pose_with_twist__functions.h"

bool
autonomy_msgs__msg__Path__init(autonomy_msgs__msg__Path * msg)
{
  if (!msg) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__init(&msg->uuid)) {
    autonomy_msgs__msg__Path__fini(msg);
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__init(&msg->name)) {
    autonomy_msgs__msg__Path__fini(msg);
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    autonomy_msgs__msg__Path__fini(msg);
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__init(&msg->info)) {
    autonomy_msgs__msg__Path__fini(msg);
    return false;
  }
  // poses
  if (!autonomy_msgs__msg__PoseWithTwist__Sequence__init(&msg->poses, 0)) {
    autonomy_msgs__msg__Path__fini(msg);
    return false;
  }
  return true;
}

void
autonomy_msgs__msg__Path__fini(autonomy_msgs__msg__Path * msg)
{
  if (!msg) {
    return;
  }
  // uuid
  rosidl_runtime_c__String__fini(&msg->uuid);
  // name
  rosidl_runtime_c__String__fini(&msg->name);
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // info
  autonomy_msgs__msg__CoordinateSystemInfo__fini(&msg->info);
  // poses
  autonomy_msgs__msg__PoseWithTwist__Sequence__fini(&msg->poses);
}

bool
autonomy_msgs__msg__Path__are_equal(const autonomy_msgs__msg__Path * lhs, const autonomy_msgs__msg__Path * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->uuid), &(rhs->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->name), &(rhs->name)))
  {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__are_equal(
      &(lhs->info), &(rhs->info)))
  {
    return false;
  }
  // poses
  if (!autonomy_msgs__msg__PoseWithTwist__Sequence__are_equal(
      &(lhs->poses), &(rhs->poses)))
  {
    return false;
  }
  return true;
}

bool
autonomy_msgs__msg__Path__copy(
  const autonomy_msgs__msg__Path * input,
  autonomy_msgs__msg__Path * output)
{
  if (!input || !output) {
    return false;
  }
  // uuid
  if (!rosidl_runtime_c__String__copy(
      &(input->uuid), &(output->uuid)))
  {
    return false;
  }
  // name
  if (!rosidl_runtime_c__String__copy(
      &(input->name), &(output->name)))
  {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // info
  if (!autonomy_msgs__msg__CoordinateSystemInfo__copy(
      &(input->info), &(output->info)))
  {
    return false;
  }
  // poses
  if (!autonomy_msgs__msg__PoseWithTwist__Sequence__copy(
      &(input->poses), &(output->poses)))
  {
    return false;
  }
  return true;
}

autonomy_msgs__msg__Path *
autonomy_msgs__msg__Path__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Path * msg = (autonomy_msgs__msg__Path *)allocator.allocate(sizeof(autonomy_msgs__msg__Path), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(autonomy_msgs__msg__Path));
  bool success = autonomy_msgs__msg__Path__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
autonomy_msgs__msg__Path__destroy(autonomy_msgs__msg__Path * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    autonomy_msgs__msg__Path__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
autonomy_msgs__msg__Path__Sequence__init(autonomy_msgs__msg__Path__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Path * data = NULL;

  if (size) {
    data = (autonomy_msgs__msg__Path *)allocator.zero_allocate(size, sizeof(autonomy_msgs__msg__Path), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = autonomy_msgs__msg__Path__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        autonomy_msgs__msg__Path__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
autonomy_msgs__msg__Path__Sequence__fini(autonomy_msgs__msg__Path__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      autonomy_msgs__msg__Path__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

autonomy_msgs__msg__Path__Sequence *
autonomy_msgs__msg__Path__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  autonomy_msgs__msg__Path__Sequence * array = (autonomy_msgs__msg__Path__Sequence *)allocator.allocate(sizeof(autonomy_msgs__msg__Path__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = autonomy_msgs__msg__Path__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
autonomy_msgs__msg__Path__Sequence__destroy(autonomy_msgs__msg__Path__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    autonomy_msgs__msg__Path__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
autonomy_msgs__msg__Path__Sequence__are_equal(const autonomy_msgs__msg__Path__Sequence * lhs, const autonomy_msgs__msg__Path__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!autonomy_msgs__msg__Path__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
autonomy_msgs__msg__Path__Sequence__copy(
  const autonomy_msgs__msg__Path__Sequence * input,
  autonomy_msgs__msg__Path__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(autonomy_msgs__msg__Path);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    autonomy_msgs__msg__Path * data =
      (autonomy_msgs__msg__Path *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!autonomy_msgs__msg__Path__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          autonomy_msgs__msg__Path__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!autonomy_msgs__msg__Path__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
