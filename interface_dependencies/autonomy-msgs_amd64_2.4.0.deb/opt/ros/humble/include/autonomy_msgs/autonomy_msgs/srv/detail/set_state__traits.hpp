// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from autonomy_msgs:srv/SetState.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__TRAITS_HPP_
#define AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "autonomy_msgs/srv/detail/set_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace autonomy_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetState_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: state
  {
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetState_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetState_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::srv::SetState_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::srv::SetState_Request & msg)
{
  return autonomy_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::srv::SetState_Request>()
{
  return "autonomy_msgs::srv::SetState_Request";
}

template<>
inline const char * name<autonomy_msgs::srv::SetState_Request>()
{
  return "autonomy_msgs/srv/SetState_Request";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetState_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetState_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::srv::SetState_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace autonomy_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const SetState_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SetState_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SetState_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace autonomy_msgs

namespace rosidl_generator_traits
{

[[deprecated("use autonomy_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const autonomy_msgs::srv::SetState_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  autonomy_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use autonomy_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const autonomy_msgs::srv::SetState_Response & msg)
{
  return autonomy_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<autonomy_msgs::srv::SetState_Response>()
{
  return "autonomy_msgs::srv::SetState_Response";
}

template<>
inline const char * name<autonomy_msgs::srv::SetState_Response>()
{
  return "autonomy_msgs/srv/SetState_Response";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetState_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetState_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<autonomy_msgs::srv::SetState_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<autonomy_msgs::srv::SetState>()
{
  return "autonomy_msgs::srv::SetState";
}

template<>
inline const char * name<autonomy_msgs::srv::SetState>()
{
  return "autonomy_msgs/srv/SetState";
}

template<>
struct has_fixed_size<autonomy_msgs::srv::SetState>
  : std::integral_constant<
    bool,
    has_fixed_size<autonomy_msgs::srv::SetState_Request>::value &&
    has_fixed_size<autonomy_msgs::srv::SetState_Response>::value
  >
{
};

template<>
struct has_bounded_size<autonomy_msgs::srv::SetState>
  : std::integral_constant<
    bool,
    has_bounded_size<autonomy_msgs::srv::SetState_Request>::value &&
    has_bounded_size<autonomy_msgs::srv::SetState_Response>::value
  >
{
};

template<>
struct is_service<autonomy_msgs::srv::SetState>
  : std::true_type
{
};

template<>
struct is_service_request<autonomy_msgs::srv::SetState_Request>
  : std::true_type
{
};

template<>
struct is_service_response<autonomy_msgs::srv::SetState_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // AUTONOMY_MSGS__SRV__DETAIL__SET_STATE__TRAITS_HPP_
