// generated from rosidl_generator_c/resource/idl.h.em
// with input from autonomy_msgs:msg/Polygon.idl
// generated code does not contain a copyright notice

#ifndef AUTONOMY_MSGS__MSG__POLYGON_H_
#define AUTONOMY_MSGS__MSG__POLYGON_H_

#include "autonomy_msgs/msg/detail/polygon__struct.h"
#include "autonomy_msgs/msg/detail/polygon__functions.h"
#include "autonomy_msgs/msg/detail/polygon__type_support.h"

#endif  // AUTONOMY_MSGS__MSG__POLYGON_H_
